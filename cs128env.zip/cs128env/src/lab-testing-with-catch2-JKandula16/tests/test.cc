#ifndef CATCH_CONFIG_MAIN
#  define CATCH_CONFIG_MAIN
#endif
#include <catch/catch.hpp>
#include <iostream>
#include <string>
#include <vector>

#include "sandwich.hpp"

using std::string;
using std::vector;

// A helper method for you to visualize what the contents of a vector are. You
// are welcome to modify this method or create additional helper methods.
//
// Example usage:
//  vector<string> my_vec;
//  my_vec.push_back("hello");
//  my_vec.push_back("world"):
//  PrintVector(my_vec);
// Prints:
//  [hello, world]
void PrintVector(const vector<string>& vec) {
  std::cout << "[";
  bool first = true;
  for (const auto& it : vec) {
    if (!first) {
      std::cout << ", ";
    } else {
      first = false;
    }

    std::cout << it;
  }

  std::cout << "]" << std::endl;
}

TEST_CASE("Sandwich::AddTopping test", "[AddTopping]") {
  // your tests for Sandwich::AddTopping here
  Sandwich s;
  std::vector<std::string> the_toppings = s.GetToppings();
  s.AddTopping("lettuce");
  s.AddTopping("tomatoes");

  SECTION("adding topping increases size by one") {
    REQUIRE(s.AddTopping("peppers") == true);
  }

  s.AddTopping("cheese");
  SECTION("adding cheese when it's already there") {
    REQUIRE(s.AddTopping("cheese") == false);
  }
}

TEST_CASE("Sandwich::RemoveTopping test", "[RemoveTopping]") {
  // your tests for Sandwich::RemoveTopping here
  Sandwich s;
  std::vector<std::string> the_toppings = s.GetToppings();
  std::vector<std::string> the_sauces = s.GetDressings();
  s.AddTopping("lettuce");
  s.AddTopping("tomatoes");

  SECTION("remove topping without sauces") {
    REQUIRE(s.RemoveTopping("lettuce") == true);
  }

  SECTION("remove non-existent topping") {
    REQUIRE(s.RemoveTopping("pickles") == false);
  }

  s.AddDressing("mayo");

  SECTION("remove topping with sauces") {
    REQUIRE(s.RemoveTopping("tomatoes") == false);
  }
}

TEST_CASE("Sandwich::AddDressing test", "[AddDressing]") {
  // your tests for Sandwich::AddDressing here
  Sandwich s;
  std::vector<std::string> the_sauces = s.GetDressings();

  SECTION("dressing without topping") {
    REQUIRE(s.AddDressing("mayo") == false);
  }

  std::vector<std::string> the_toppings = s.GetToppings();
  s.AddTopping("lettuce");
  SECTION("normal adding of dressing") {
    REQUIRE(s.AddDressing("mayo") == true);
  }
  s.AddDressing("mayo");
  SECTION("duplicate dressing") { REQUIRE(s.AddDressing("mayo") == false); }
}
