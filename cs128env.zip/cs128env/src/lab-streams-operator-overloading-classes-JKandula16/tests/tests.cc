/* Framework setup */
#include "catch.hpp"

/* Includes */

/* Helpers/Constants */

/* Test Cases */

TEST_CASE("True == True", "") { REQUIRE(true == true); }