#ifndef COURSE_HPP
#define COURSE_HPP

#include <string>

struct Course {
	std::string name;
	int credits;
};

#endif
