#include <iostream>
#include <sstream>

#include "student.hpp"

int main() {
  std::ostringstream ss;
  std::vector<Course> tester = {
      {"cpsc 112", 1}, {"cpsc 226", 2}, {"help 101", 9}};
  Student st("Bob", "1234556", "cheese weasels", "Cs", tester, false);
  ss << st;
  std::cout << ss.str() << std::endl;
}
