#include "student.hpp"

#include <iostream>

Student::Student(std::string name, std::string uin, std::string net_id) {
  //"default" constructor
  name_ = name;
  uin_ = uin;
  net_id_ = net_id;
  major_ = "Undeclared";
  graduated_ = false;
}
Student::Student(std::string name,
                 std::string uin,
                 std::string net_id,
                 std::string major,
                 std::vector<Course> courses,
                 bool graduated) {
  name_ = name;
  uin_ = uin;
  net_id_ = net_id;
  major_ = major;
  courses_ = courses;
  graduated_ = graduated;
}

std::string Student::GetName() const { return name_; }
std::string Student::GetUIN() const { return uin_; }
std::string Student::GetNetId() const { return net_id_; }
std::string Student::GetMajor() const { return major_; }
bool Student::HasGraduated() const { return graduated_; }
const std::vector<Course>& Student::GetCourses() const { return courses_; }

void Student::SetName(std::string name) { name_ = name; }
void Student::SetMajor(std::string major) { major_ = major; }
bool Student::AddCourse(Course c) {
  for (size_t i = 0; i < courses_.size(); ++i) {
    if (c.name == (courses_.at(i)).name) {
      return false;
    }
  }
  courses_.push_back(c);
  return true;
}
void Student::Graduate() {
  int total = 0;
  for (size_t i = 0; i < courses_.size(); ++i) {
    total += courses_.at(i).credits;
  }
  if (total >= min_credits_grad_) {
    graduated_ = true;
  }
  if (total < min_credits_grad_) {
    graduated_ = false;
  }
}

int ReturnCredits(const Student& s) {
  std::vector<Course> trav = s.GetCourses();
  int sum = 0;
  for (size_t i = 0; i < trav.size(); ++i) {
    sum += trav.at(i).credits;
  }
  return sum;
}
std::string ReturnCourse(const Student& s) {
  std::string answer;
  for (size_t i = 0; i < s.GetCourses().size(); ++i) {
    if (i == s.GetCourses().size() - 1) {
      answer += s.GetCourses().at(i).name;
    } else {
      answer += s.GetCourses().at(i).name + ", ";
    }
  }
  return answer;
}

std::ostream& operator<<(std::ostream& os, const Student& s) {
  os << "Name: " << s.GetName() << "\n";
  os << "UIN: " << s.GetUIN() << "\n";
  os << "Net Id: " << s.GetNetId() << "\n";
  os << "Major: " << s.GetMajor() << "\n";
  os << "Credits: " << ReturnCredits(s) << "\n";
  os << "Courses: " << ReturnCourse(s) << "\n";
  if (s.HasGraduated()) {
    os << "Graduated: True";
  }
  os << "Graduated: False";

  return os;
}