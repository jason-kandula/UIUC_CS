#include "utilities.hpp"

std::string Howdy(const std::string& name) {
  std::string howdy_name = "Howdy, " + name + "!";
  return howdy_name;
}