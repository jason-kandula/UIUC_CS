#ifndef UTILITIES_HPP
#define UTILITIES_HPP

#include <string>

std::string Howdy(const std::string& name);

#endif