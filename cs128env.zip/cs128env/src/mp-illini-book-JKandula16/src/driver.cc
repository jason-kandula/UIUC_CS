#include <iostream>

#include "illini_book.hpp"

int main() {
  std::cout << "hey" << std::endl;
  IlliniBook test("example/persons.csv", "example/relations.csv");
  if (test.AreRelated(1, 2, "124")) {
    std::cout << "true" << std::endl;
  } else {
    std::cout << "false" << std::endl;
  }
  if (test.AreRelated(3, 2)) {
    std::cout << "true" << std::endl;
  } else {
    std::cout << "false" << std::endl;
  }
  // std::cout << test.GetRelated(1, 6, "128") << std::endl;

  std::vector<int> testing = test.GetSteps(1, 1);
  for (size_t i = 0; i < testing.size(); ++i) {
    std::cout << testing.at(i) << std::endl;
  }

  std::cout << "\n" << std::endl;
  std::cout << test.CountGroups() << std::endl;
  std::cout << "\n" << std::endl;
  std::cout << test.CountGroups(std::vector<std::string>{"128", "173"})
            << std::endl;
  return 0;
}
