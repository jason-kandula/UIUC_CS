#include "illini_book.hpp"

#include <fstream>

#include "utilities.hpp"

// note from discord: "use const references"

IlliniBook::IlliniBook(const std::string& people_fpath,
                       const std::string& relations_fpath) {
  std::ifstream input_file(people_fpath);
  std::string value;
  while (input_file.good()) {
    input_file >> value;
    int convert = std::stoi(value);
    graph_.insert(std::pair<int, std::set<std::pair<int, std::string>>>{
        convert, std::set<std::pair<int, std::string>>()});
  }
  input_file.close();

  std::ifstream input_file_2(relations_fpath);
  std::map<std::vector<int>, std::string> vals;
  std::vector<std::string> to_put_in_vals;
  for (std::string line; std::getline(input_file_2, line); line = "") {
    std::vector<std::string> vector = utilities::Split(line, ',');
    int one_val = std::stoi(vector.at(0));
    int two_val = std::stoi(vector.at(1));
    if (graph_.count(one_val) > 0 && graph_.count(two_val) > 0) {
      std::pair<int, std::string> to_add(two_val, vector.at(2));
      graph_.at(one_val).insert(to_add);
      std::pair<int, std::string> to_add_two(one_val, vector.at(2));
      graph_.at(two_val).insert(to_add_two);
    }
  }

  input_file_2.close();
  // for the corresponding key, make a pair of the value and add them to the set
}

bool IlliniBook::AreRelated(int uin_1, int uin_2) const {
  bool answer = false;
  std::map<int, int> depth_tracker;
  std::queue<int> visited;
  std::set<int> visited_set;
  visited.push(uin_1);
  visited_set.insert(uin_1);
  depth_tracker.insert({uin_1, 0});
  while (!visited.empty()) {
    int temp = visited.front();
    visited.pop();
    for (const auto& p : graph_.at(temp)) {
      if (p.first == uin_2) {
        answer = true;
        return answer;
      }
      if (visited_set.count(p.first) == 0) {
        visited.push(p.first);
        visited_set.insert(p.first);
        depth_tracker.insert({(p.first), depth_tracker[temp] + 1});
      }
    }
  }
  answer = false;
  return answer;
}

bool IlliniBook::AreRelated(int uin_1,
                            int uin_2,
                            const std::string& relationship) const {
  bool answer = false;
  std::map<int, int> depth_tracker;
  std::queue<int> visited;
  std::set<int> visited_set;
  visited.push(uin_1);
  visited_set.insert(uin_1);
  depth_tracker.insert({uin_1, 0});
  while (!visited.empty()) {
    int temp = visited.front();
    visited.pop();
    for (const std::pair<int, std::string>& p : graph_.at(temp)) {
      if (p.first == uin_2 && p.second == relationship) {
        answer = true;
        return answer;
      }
      if (visited_set.count(p.first) == 0 && p.second == relationship) {
        visited.push(p.first);
        visited_set.insert(p.first);
        depth_tracker.insert({(p.first), depth_tracker[temp] + 1});
      }
    }
  }
  answer = false;
  return answer;
}

int IlliniBook::GetRelated(int uin_1, int uin_2) const {
  int answer = 0;
  std::map<int, int> depth_tracker;
  std::queue<int> visited;
  std::set<int> visited_set;
  visited.push(uin_1);
  visited_set.insert(uin_1);
  depth_tracker.insert({uin_1, 0});
  while (!visited.empty()) {
    int temp = visited.front();
    visited.pop();
    for (const std::pair<int, std::string>& p : graph_.at(temp)) {
      if (p.first == uin_2) {
        return depth_tracker.at(temp) + 1;
      }
      if (visited_set.count(p.first) == 0) {
        visited.push(p.first);
        visited_set.insert(p.first);
        depth_tracker.insert({(p.first), depth_tracker[temp] + 1});
      }
    }
  }
  if (depth_tracker.count(uin_2) > 0) {
    answer = depth_tracker.at(uin_2);
    return answer;
  }
  return -1;
}

int IlliniBook::GetRelated(int uin_1,
                           int uin_2,
                           const std::string& relationship) const {
  int answer = 0;
  std::map<int, int> depth_tracker;
  std::queue<int> visited;
  std::set<int> visited_set;
  visited.push(uin_1);
  visited_set.insert(uin_1);
  depth_tracker.insert({uin_1, 0});
  while (!visited.empty()) {
    int temp = visited.front();
    visited.pop();
    for (const std::pair<int, std::string>& p : graph_.at(temp)) {
      if (p.first == uin_2 && p.second == relationship) {
        return depth_tracker.at(temp) + 1;
      }
      if (visited_set.count(p.first) == 0 && p.second == relationship) {
        visited.push(p.first);
        visited_set.insert(p.first);
        depth_tracker.insert({(p.first), depth_tracker[temp] + 1});
      }
    }
  }
  if (depth_tracker.count(uin_2) > 0) {
    answer = depth_tracker.at(uin_2);
    return answer;
  }
  return -1;
}

std::vector<int> IlliniBook::GetSteps(int uin, int n) const {
  std::vector<int> answer;

  std::queue<int> depth_tracker;
  std::queue<int> visited;
  std::set<int> visited_set;
  visited.push(uin);
  visited_set.insert(uin);
  depth_tracker.push(0);
  int tracking = depth_tracker.front();

  while (!visited.empty() && depth_tracker.front() < n) {
    int temp = visited.front();
    tracking = depth_tracker.front();
    visited.pop();
    depth_tracker.pop();
    for (const std::pair<int, std::string>& p : graph_.at(temp)) {
      if (visited_set.count(p.first) == 0) {
        if (tracking == n - 1) {
          answer.push_back(p.first);
        }
        visited.push(p.first);
        visited_set.insert(p.first);
        depth_tracker.push(tracking + 1);
      }
    }
  }
  return answer;
}

std::vector<int> IlliniBook::DFS(std::vector<bool>& vec,
                                 int origin,
                                 std::vector<int>& visited) const {
  vec[origin] = true;
  visited.push_back(origin);

  for (const std::pair<int, std::string>& p : graph_.at(origin)) {
    if (!vec[p.first]) {
      visited = DFS(vec, p.first, visited);
    }
  }
  return visited;
}

size_t IlliniBook::CountGroups() const {
  size_t counter = 0;

  std::vector<int> uins;
  std::list<int> uins_list;
  std::vector<bool> vec;
  for (auto const& [key, value] : graph_) {
    uins.push_back(key);
  }
  for (int uin : uins) {
    uins_list.push_back(uin);
  }
  while (!uins_list.empty()) {
    int start = uins_list.front();
    for (size_t i = 0; i < uins_list.size(); ++i) {
      vec.push_back(false);
    }
    std::vector<int> bfs;
    bfs = DFS(vec, start, bfs);
    for (int uin : bfs) {
      uins_list.remove(uin);
    }
    counter++;
  }
  return counter;
}

std::vector<int> IlliniBook::DFSWithRelation(
    std::vector<bool>& vec,
    int origin,
    std::vector<int>& visited,
    const std::string& relation) const {
  vec[origin] = true;
  visited.push_back(origin);

  for (const std::pair<int, std::string>& p : graph_.at(origin)) {
    if (!vec[p.first] && p.second == relation) {
      visited = DFSWithRelation(vec, p.first, visited, relation);
    }
  }
  return visited;
}

size_t IlliniBook::CountGroups(const std::string& relationship) const {
  size_t counter = 0;
  std::vector<int> uins;
  std::list<int> uins_list;
  std::vector<bool> vec;
  for (auto const& [key, value] : graph_) {
    uins.push_back(key);
  }
  for (int uin : uins) {
    uins_list.push_back(uin);
  }
  while (!uins_list.empty()) {
    int start = uins_list.front();
    for (size_t i = 0; i < uins_list.size(); ++i) {
      vec.push_back(false);
    }
    std::vector<int> bfs;
    bfs = DFSWithRelation(vec, start, bfs, relationship);
    for (int uin : bfs) {
      uins_list.remove(uin);
    }
    counter++;
  }
  return counter;
}

std::vector<int> IlliniBook::DFSWithMultipleRelations(
    std::vector<bool>& vec,
    int origin,
    std::vector<int>& visited,
    std::set<std::string>& relation) const {
  vec[origin] = true;
  visited.push_back(origin);

  for (const std::pair<int, std::string>& p : graph_.at(origin)) {
    if (!vec[p.first] && relation.count(p.second) > 0) {
      visited = DFSWithMultipleRelations(vec, p.first, visited, relation);
    }
  }
  return visited;
}

size_t IlliniBook::CountGroups(
    const std::vector<std::string>& relationships) const {
  size_t counter = 0;
  std::set<std::string> set_relationships;
  std::vector<int> uins;
  std::list<int> uins_list;
  std::vector<bool> vec;
  for (size_t i = 0; i < relationships.size(); ++i) {
    set_relationships.insert(relationships.at(i));
  }
  for (auto const& [key, value] : graph_) {
    uins.push_back(key);
  }
  for (int uin : uins) {
    uins_list.push_back(uin);
  }
  while (!uins_list.empty()) {
    int start = uins_list.front();
    for (size_t i = 0; i < uins_list.size(); ++i) {
      vec.push_back(false);
    }
    std::vector<int> bfs;
    bfs = DFSWithMultipleRelations(vec, start, bfs, set_relationships);
    for (int uin : bfs) {
      uins_list.remove(uin);
    }
    counter++;
  }
  return counter;
}
