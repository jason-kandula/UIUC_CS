#include <iostream>
#include <stdexcept>
#include <vector>

#include "doubly_linked_list.hpp"

using namespace std;

int main() {}
