#ifndef CATCH_CONFIG_MAIN
#  define CATCH_CONFIG_MAIN
#endif
#include "catch.hpp"
#include "zoo.hpp"

using std::string;
using std::vector;

TEST_CASE("Add your tests here", "") {
  Zoo zoo;
  int habitats[] = {1, 2, 3};
  int* h1 = &habitats[0];
  int* h2 = &habitats[1];
  int* h3 = &habitats[2];
  Animal panda("PeculiarPanda", 12, 50, 300, h1);
  Animal seal("SmartSeal", 7, 20, 200, h2);
  Animal badger("Breezy Badger", 4, 5, 50, h3);
  zoo.AddAnimal(&panda);
  zoo.AddAnimal(&seal);
  zoo.AddAnimal(&badger);
  REQUIRE((zoo.GetAnimals()).size() == 2);
}