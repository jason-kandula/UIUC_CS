#include "board.hpp"

// you might need additional includes
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

/**************************************************************************/
/* your function definitions                                              */
/**************************************************************************/

void InitBoard(Board& b) {
  // below was minimal to get tests to actually compile and given test case to
  // fail
  for (size_t i = 0; i < Board::kBoardHeight; ++i) {
    for (size_t j = 0; j < Board::kBoardWidth; ++j) {
      b.board[i][j] = DiskType::kEmpty;
    }
  }
}

void DropDiskToBoard(Board& b, DiskType disk, int col) {
  if (col >= Board::kBoardWidth || col < 0) {
    throw std::runtime_error("col out of bounds");
  }
  int check = 0;
  for (size_t i = 0; i < Board::kBoardHeight; ++i) {
    if (b.board[i][col] != DiskType::kEmpty) {
      check++;
    } else {
      b.board[i][col] = disk;
      break;
    }
  }
  if (check == Board::kBoardHeight) {
    throw std::runtime_error("full column");
  }
}

bool CheckForWinner(Board& b, DiskType disk) {
  bool ans = false;
  bool check1 = SearchForWinner(b, disk, WinningDirection::kHorizontal);
  bool check2 = SearchForWinner(b, disk, WinningDirection::kLeftDiag);
  bool check3 = SearchForWinner(b, disk, WinningDirection::kRightDiag);
  bool check4 = SearchForWinner(b, disk, WinningDirection::kVertical);

  if (check1 || check2 || check3 || check4) {
    ans = true;
  }
  return ans;
}

bool SearchHorizontal(Board& b, DiskType disk) {
  bool ans = false;
  int count = 0;
  for (size_t i = 0; i < Board::kBoardHeight; ++i) {
    count = 0;
    for (size_t j = 0; j < Board::kBoardWidth; ++j) {
      if (b.board[i][j] == disk) {
        count++;
      } else if (count == 4) {
        ans = true;
        return ans;
      } else {
        count = 0;
        continue;
      }
    }
    if (count == 4) {
      ans = true;
      return ans;
    }
  }
  return ans;
}

bool SearchVertical(Board& b, DiskType disk) {
  bool ans = false;
  int count = 0;
  for (size_t i = 0; i < Board::kBoardWidth; ++i) {
    count = 0;
    for (size_t j = 0; j < Board::kBoardHeight; ++j) {
      if (b.board[j][i] == disk) {
        count++;
      } else if (count == 4) {
        ans = true;
        return ans;
      } else {
        count = 0;
        continue;
      }
    }
    if (count == 4) {
      ans = true;
      return ans;
    }
  }
  return ans;
}

bool SearchLeftDiagonal(Board& b, DiskType disk) {
  bool ans = false;
  int count = 0;
  for (size_t i = (Board::kBoardWidth - 1); i >= 3; --i) {
    count = 0;
    for (size_t j = 0; j < Board::kBoardHeight; ++j) {
      if (b.board[j][i] == disk) {
        count++;
        i--;
      } else if (count == 4) {
        ans = true;
        return ans;
      } else {
        count = 0;
        continue;
      }
    }
    if (count == 4) {
      ans = true;
      return ans;
    }
  }
  return ans;
}

bool SearchRightDiagonal(Board& b, DiskType disk) {
  bool ans = false;
  int count = 0;
  for (size_t i = 0; i <= 3; ++i) {
    count = 0;
    for (size_t j = 0; j < Board::kBoardHeight; ++j) {
      if (b.board[j][i] == disk) {
        count++;
        i++;
      } else if (count == 4) {
        ans = true;
        return ans;
      } else {
        count = 0;
        continue;
      }
    }
    if (count == 4) {
      ans = true;
      return ans;
    }
  }
  return ans;
}

bool SearchForWinner(Board& b, DiskType disk, WinningDirection to_check) {
  bool check1 = false;
  bool check2 = false;
  bool ans = false;
  bool check3 = false;
  bool check4 = false;
  if (to_check == WinningDirection::kHorizontal) {
    check1 = SearchHorizontal(b, disk);
  }
  if (to_check == WinningDirection::kVertical) {
    check2 = SearchVertical(b, disk);
  }

  if (to_check == WinningDirection::kLeftDiag) {
    check3 = SearchLeftDiagonal(b, disk);
  }

  if (to_check == WinningDirection::kRightDiag) {
    check4 = SearchRightDiagonal(b, disk);
  }

  if (check1 || check2 || check3 || check4) {
    ans = true;
  }
  return ans;
}

bool BoardLocationInBounds(int row, int col) {
  if (row >= 0 && row < Board::kBoardHeight) {
    if (col >= 0 && col < Board::kBoardWidth) {
      return true;
    }
  }
  return false;
}
/**************************************************************************/
/* provided to you                                                        */
/**************************************************************************/
std::string BoardToStr(const Board& b) {
  constexpr int kTotalWidth = Board::kBoardWidth * 11 - Board::kBoardHeight - 1;
  std::stringstream ss;
  ss << std::endl;
  for (int row = Board::kBoardHeight; row > 0; --row) {
    ss << " |";
    for (int col = 0; col < Board::kBoardWidth; ++col) {
      std::string value_here;
      value_here.push_back(static_cast<char>(b.board[row - 1][col]));
      ss << ' ' << CenterStr(value_here, Board::kBoardWidth + 1) << '|';
    }
    ss << std::endl;
    ss << " |" << std::setw(kTotalWidth) << std::setfill('-') << '|'
       << std::endl;
  }
  ss << " |";
  for (int col = 0; col < Board::kBoardWidth; ++col) {
    ss << ' ' << CenterStr(std::to_string(col), Board::kBoardWidth + 1) << '|';
  }
  return ss.str();
}

std::string CenterStr(const std::string& str, int col_width) {
  // quick and easy (but error-prone) implementation
  auto padl = (col_width - str.length()) / 2;
  auto padr = (col_width - str.length()) - padl;
  std::string strf = std::string(padl, ' ') + str + std::string(padr, ' ');
  return strf;
}