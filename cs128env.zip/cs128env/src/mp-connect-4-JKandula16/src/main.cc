#include <iostream>

#include "board.hpp"

int main() {
  // Board b;
  Board c;
  InitBoard(c);
  DropDiskToBoard(c, DiskType::kPlayer1, 0);
  DropDiskToBoard(c, DiskType::kPlayer1, 0);
  DropDiskToBoard(c, DiskType::kPlayer1, 0);
  DropDiskToBoard(c, DiskType::kPlayer1, 0);

  DropDiskToBoard(c, DiskType::kPlayer2, 1);
  DropDiskToBoard(c, DiskType::kPlayer2, 2);
  DropDiskToBoard(c, DiskType::kPlayer2, 3);
  DropDiskToBoard(c, DiskType::kPlayer2, 4);
  std::cout << BoardToStr(c) << std::endl;
  std::cout << SearchForWinner(
                   c, DiskType::kPlayer2, WinningDirection::kHorizontal)
            << std::endl;
  ;
  std::cout << SearchForWinner(
                   c, DiskType::kPlayer1, WinningDirection::kVertical)
            << std::endl;
  DropDiskToBoard(c, DiskType::kPlayer1, 1);

  DropDiskToBoard(c, DiskType::kPlayer2, 2);
  DropDiskToBoard(c, DiskType::kPlayer1, 2);

  DropDiskToBoard(c, DiskType::kPlayer2, 3);
  DropDiskToBoard(c, DiskType::kPlayer2, 3);
  DropDiskToBoard(c, DiskType::kPlayer1, 3);

  std::cout << BoardToStr(c) << std::endl;
  std::cout << SearchForWinner(
                   c, DiskType::kPlayer1, WinningDirection::kRightDiag)
            << std::endl;
}