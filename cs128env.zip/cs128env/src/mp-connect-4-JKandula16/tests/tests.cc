// clang-format off
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
//  Written By : Michael R. Nowak                Environment : ubuntu:latest               //
//  Date ......: 2022/02/07                      Compiler ...: clang-10                    //
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
// clang-format on
/////////////////////////////////////////////////////////////////////////////////////////////
//                             Framework Set-up //
/////////////////////////////////////////////////////////////////////////////////////////////
#ifndef CATCH_CONFIG_MAIN
#  define CATCH_CONFIG_MAIN
#endif

#include "catch.hpp"

/////////////////////////////////////////////////////////////////////////////////////////////
//                                 Includes //
/////////////////////////////////////////////////////////////////////////////////////////////
#include <stdexcept>

#include "board.hpp"

/////////////////////////////////////////////////////////////////////////////////////////////
//                             Helpers/Constants //
/////////////////////////////////////////////////////////////////////////////////////////////
constexpr int kBoardWidth = 7;
constexpr int kBoardHeight = 6;

bool AreEqual(DiskType solution[][kBoardWidth],
              DiskType student[][kBoardWidth]) {
  for (int i = 0; i < kBoardHeight; ++i) {
    for (int j = 0; j < kBoardWidth; ++j) {
      if (solution[i][j] != student[i][j]) return false;
    }
  }
  return true;
}

/////////////////////////////////////////////////////////////////////////////////////////////
//                                Test Cases //
/////////////////////////////////////////////////////////////////////////////////////////////

TEST_CASE("Board initialization", "[board_init]") {
  // SECTION("Can use sections") {}
  // clang-format off
  DiskType solution[kBoardHeight][kBoardWidth] = { 
    {DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty}, 
    {DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty}, 
    {DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty}, 
    {DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty}, 
    {DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty}, 
    {DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty, DiskType::kEmpty} 
  };
  // clang-format on
  Board student;  // NOLINT
  InitBoard(student);
  REQUIRE(AreEqual(solution, student.board));
}

TEST_CASE("Disk dropping into board", "[drop_disk_to_board]") {
  SECTION("invalid column parameter, too large or too small") {
    // initialize the board with the inintboard function
    // call the drop disk function with an out of range col
    // require that no new piece was dropped
    Board c;
    InitBoard(c);
    REQUIRE_THROWS_AS((DropDiskToBoard(c, DiskType::kPlayer1, 10)),
                      std::runtime_error);
    REQUIRE_THROWS_AS((DropDiskToBoard(c, DiskType::kPlayer1, -5)),
                      std::runtime_error);
  }
}

TEST_CASE(
    "Search for Winner"
    "[search_for_winner_function]") {
  SECTION("horizontal winner") {
    Board c;
    InitBoard(c);
    DropDiskToBoard(c, DiskType::kPlayer1, 0);
    DropDiskToBoard(c, DiskType::kPlayer1, 1);
    DropDiskToBoard(c, DiskType::kPlayer1, 2);
    REQUIRE(SearchForWinner(
                c, DiskType::kPlayer1, WinningDirection::kHorizontal) == false);
    DropDiskToBoard(c, DiskType::kPlayer1, 3);
    REQUIRE(SearchForWinner(
                c, DiskType::kPlayer1, WinningDirection::kHorizontal) == true);
  }
  SECTION("vertical winner") {
    Board c;
    InitBoard(c);
    DropDiskToBoard(c, DiskType::kPlayer1, 0);
    DropDiskToBoard(c, DiskType::kPlayer1, 0);
    DropDiskToBoard(c, DiskType::kPlayer1, 0);
    DropDiskToBoard(c, DiskType::kPlayer1, 0);
    REQUIRE(SearchForWinner(
                c, DiskType::kPlayer1, WinningDirection::kVertical) == true);
  }

  SECTION("right diagonal") {
    Board c;
    InitBoard(c);
    DropDiskToBoard(c, DiskType::kPlayer1, 0);

    DropDiskToBoard(c, DiskType::kPlayer2, 1);
    DropDiskToBoard(c, DiskType::kPlayer1, 1);

    DropDiskToBoard(c, DiskType::kPlayer2, 2);
    DropDiskToBoard(c, DiskType::kPlayer2, 2);
    DropDiskToBoard(c, DiskType::kPlayer1, 2);

    DropDiskToBoard(c, DiskType::kPlayer2, 3);
    DropDiskToBoard(c, DiskType::kPlayer2, 3);
    DropDiskToBoard(c, DiskType::kPlayer2, 3);
    DropDiskToBoard(c, DiskType::kPlayer1, 3);
    REQUIRE(SearchForWinner(
                c, DiskType::kPlayer1, WinningDirection::kRightDiag) == true);
  }
}

TEST_CASE("BoardLocationInBounds", "[in_bounds]") {
  SECTION("out of range row or col") {
    Board test;
    InitBoard(test);
    REQUIRE(BoardLocationInBounds(0, 11) == false);
    REQUIRE(BoardLocationInBounds(-2, 5) == false);
    REQUIRE(BoardLocationInBounds(1, 8) == false);
    REQUIRE(BoardLocationInBounds(4, -19) == false);
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////