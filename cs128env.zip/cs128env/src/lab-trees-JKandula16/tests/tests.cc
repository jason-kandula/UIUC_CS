#ifndef CATCH_CONFIG_MAIN
#  define CATCH_CONFIG_MAIN
#endif
#include <iostream>

#include "binary_search_tree.hpp"
#include "catch.hpp"
#include "tree_node.hpp"

TEST_CASE("Sanity Check", "[sanity_check]") { REQUIRE(true); }