#include "cord.hpp"

#include "cord-utilities.hpp"

Cord::Cord(const std::string& dat) {
  data_ = dat;
  length_ = dat.length();
}

Cord::Cord(const std::shared_ptr<Cord>& left_cord,
           const std::shared_ptr<Cord>& right_cord) {
  // TODO
  if (left_cord == nullptr || right_cord == nullptr) {
    if (left_cord == nullptr && right_cord != nullptr) {
      right_ = right_cord;
      length_ = right_->Length();
      data_ = right_->GetData();
    }
    if (left_cord != nullptr && right_cord == nullptr) {
      left_ = left_cord;
      length_ = left_->Length();
      data_ = left_->GetData();
    }
  } else {
    left_ = left_cord;
    right_ = right_cord;

    length_ = left_->Length() + right_->Length();
    data_ = left_->GetData() + right_->GetData();
  }
}

size_t Cord::Length() const { return length_; }

std::shared_ptr<Cord> Cord::GetLeft() const { return left_; }

std::shared_ptr<Cord> Cord::GetRight() const { return right_; }

const std::string& Cord::GetData() const { return data_; }

std::string Cord::ToStringHelper(std::string& answer) const {
  if (this->GetLeft() == nullptr && this->GetRight() == nullptr) {
    answer += this->GetData();
  }
  if (this->GetLeft() != nullptr) {
    answer = left_->ToStringHelper(answer);
  }
  if (this->GetRight() != nullptr) {
    answer = right_->ToStringHelper(answer);
  }

  return answer;
}
std::string Cord::ToString() const {
  // TODO
  std::string answer;
  if (this->GetLeft() == nullptr && this->GetRight() == nullptr) {
    answer += this->GetData();
  }
  if (this->GetLeft() != nullptr) {
    answer = left_->ToStringHelper(answer);
  }
  if (this->GetRight() != nullptr) {
    answer = right_->ToStringHelper(answer);
  }

  return answer;
}

std::shared_ptr<Cord> Cord::GetStartingCord(size_t lower_idx,
                                            size_t& iterate,
                                            size_t& counter,
                                            std::shared_ptr<Cord> to_return) {
  // get to the starting cord, at the starting index
  if (this->GetLeft() == nullptr && this->GetRight()) {
    while (iterate < length_ - 1 && counter < lower_idx) {
      iterate++;
      counter++;
    }
    if (counter == lower_idx) {
      to_return = std::make_shared<Cord>(this);
      return to_return;
    }
    iterate = 0;
    counter++;
  }
  if (this->GetLeft() != nullptr) {
    to_return = left_->GetStartingCord(lower_idx, iterate, counter, to_return);
    if (to_return != nullptr && counter == lower_idx) {
      return to_return;
    }
  }
  if (this->GetRight() != nullptr) {
    to_return = right_->GetStartingCord(lower_idx, iterate, counter, to_return);
    if (to_return != nullptr && counter == lower_idx) {
      return to_return;
    }
  }
  return to_return;
}

std::shared_ptr<Cord> Cord::SubStringHelper(size_t counter,
                                            size_t lower_idx,
                                            size_t upper_idx,
                                            std::shared_ptr<Cord> final_answer,
                                            std::shared_ptr<Cord> final_one,
                                            std::shared_ptr<Cord> final_two) {
  size_t iterate = 0;
  if (this->GetLeft() == nullptr && this->GetRight() == nullptr) {
    while (iterate < length_ - 1 && counter < upper_idx) {
      iterate++, counter++;
    }
    if ((iterate == length_ - 1) &&
        (counter != upper_idx || counter == upper_idx)) {
      if (final_one == nullptr) {
        final_one = std::make_shared<Cord>(this->GetData());
      } else if (final_two == nullptr) {
        final_two = std::make_shared<Cord>(this->GetData());
      }
    } else if (iterate != length_ - 1 && counter == upper_idx) {
      if (final_one == nullptr) {
        final_one =
            std::make_shared<Cord>(this->GetData().substr(0, upper_idx));
      } else if (final_two == nullptr) {
        final_two =
            std::make_shared<Cord>(this->GetData().substr(0, upper_idx));
      }
    }
    counter++;
    final_answer = std::make_shared<Cord>(final_one, final_two);
    return final_answer;
  }
  if (this->GetLeft() != nullptr) {
    final_answer = left_->SubStringHelper(
        counter, lower_idx, upper_idx, final_answer, final_one, final_two);
    if (final_answer->GetLeft() != nullptr &&
        final_answer->GetRight() != nullptr && counter == upper_idx) {
      return final_answer;
    }
  }
  if (this->GetRight() != nullptr) {
    final_answer = right_->SubStringHelper(
        counter, lower_idx, upper_idx, final_answer, final_one, final_two);
    if (final_answer->GetLeft() != nullptr &&
        final_answer->GetRight() != nullptr && counter == upper_idx) {
      return final_answer;
    }
  }
}

std::shared_ptr<Cord> Cord::SubString(size_t lower_idx, size_t upper_idx) {
  // TODO
  if (lower_idx < 0 && upper_idx >= length_) {
    return nullptr;
  }
  std::shared_ptr<Cord> final_answer;
  std::shared_ptr<Cord> final_one = nullptr;
  std::shared_ptr<Cord> final_two = nullptr;
  std::shared_ptr<Cord> starting = nullptr;
  size_t iterate = 0;
  size_t counter = 0;

  starting = GetStartingCord(lower_idx, iterate, counter, starting);

  if (starting->GetLeft() == nullptr && starting->GetRight() == nullptr) {
    while (iterate < length_ - 1 && counter < upper_idx) {
      iterate++, counter++;
    }
    if ((iterate == length_ - 1) &&
        (counter != upper_idx || counter == upper_idx)) {
      if (final_one == nullptr) {
        final_one = std::make_shared<Cord>(starting->GetData());
      } else if (final_two == nullptr) {
        final_two = std::make_shared<Cord>(starting->GetData());
      }
    } else if (iterate != length_ - 1 && counter == upper_idx) {
      if (final_one == nullptr) {
        final_one =
            std::make_shared<Cord>(starting->GetData().substr(0, upper_idx));
      } else if (final_two == nullptr) {
        final_two =
            std::make_shared<Cord>(starting->GetData().substr(0, upper_idx));
      }
    }
    counter++;
    final_answer = std::make_shared<Cord>(final_one, final_two);
    return final_answer;
  }
  if (starting->GetLeft() != nullptr) {
    final_answer = left_->SubStringHelper(
        counter, lower_idx, upper_idx, final_answer, final_one, final_two);
    if (final_answer->GetLeft() != nullptr &&
        final_answer->GetRight() != nullptr && counter == upper_idx) {
      return final_answer;
    }
  }
  if (starting->GetRight() != nullptr) {
    final_answer = right_->SubStringHelper(
        counter, lower_idx, upper_idx, final_answer, final_one, final_two);
    if (final_answer->GetLeft() != nullptr &&
        final_answer->GetRight() != nullptr && counter == upper_idx) {
      return final_answer;
    }
  }

  return final_answer;
}

char Cord::AtHelper(size_t idx, size_t& counter) const {
  char answer = '\n';
  size_t iterate = 0;
  if (this->GetLeft() == nullptr && this->GetRight() == nullptr) {
    // do stuff
    while (iterate < length_ - 1 && counter < idx) {
      iterate++;
      counter++;
    }
    if (counter == idx) {
      answer = this->GetData().at(iterate);
      return answer;
    }
    counter++;
  }
  if (this->GetLeft() != nullptr) {
    answer = left_->AtHelper(idx, counter);
    if (answer != '\n' && counter == idx) {
      return answer;
    }
  }
  if (this->GetRight() != nullptr) {
    answer = right_->AtHelper(idx, counter);
    if (answer != '\n' && counter == idx) {
      return answer;
    }
  }
  return answer;
}

char Cord::At(size_t idx) const {
  // TODO
  if (idx >= length_) {
    throw std::invalid_argument("wrong");
  }
  char answer = '\n';
  size_t counter = 0;
  size_t iterate = 0;
  if (this->GetLeft() == nullptr && this->GetRight() == nullptr) {
    // do stuff
    while (iterate < length_ - 1 && counter < idx) {
      iterate++;
      counter++;
    }
    if (counter == idx) {
      answer = this->GetData().at(iterate);
      return answer;
    }
    counter++;
  }
  if (this->GetLeft() != nullptr) {
    answer = left_->AtHelper(idx, counter);
    if (answer != '\n' && counter == idx) {
      return answer;
    }
  }
  if (this->GetRight() != nullptr) {
    answer = right_->AtHelper(idx, counter);
    if (answer != '\n' && counter == idx) {
      return answer;
    }
  }

  return answer;
}

bool Cord::IsValidCord() const {
  // TODO
  return true;
}
