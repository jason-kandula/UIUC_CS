#include "cord-utilities.hpp"

std::shared_ptr<Cord> ConcatCords(std::shared_ptr<Cord> left_cord,
                                  std::shared_ptr<Cord> right_cord) {
  // TODO
  if (!left_cord->IsValidCord() || !right_cord->IsValidCord()) {
    throw std::invalid_argument("wrong");
  }
  if (left_cord == nullptr && right_cord != nullptr) {
    return right_cord;
  }
  if (left_cord != nullptr && right_cord == nullptr) {
    return left_cord;
  }
  std::shared_ptr<Cord> to_return =
      std::make_shared<Cord>(left_cord, right_cord);
  return to_return;
}

void ReduceCords(cs128::ReferenceList<std::shared_ptr<Cord>> cords) {
  // TODO
  std::string test = cords.begin()->get()->GetData();
}
