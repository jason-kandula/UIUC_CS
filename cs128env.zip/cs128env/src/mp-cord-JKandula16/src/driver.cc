#include <cassert>
#include <iostream>

#include "cord-utilities.hpp"
#include "cord.hpp"

int main() {
  // includes/cord-utilities.hpp
  // includes/cord-utilities.hpp
  // src/cord-utilities.cc
  // src/cord-utilities.cc

  std::shared_ptr<Cord> cheese = std::make_shared<Cord>("cheese");
  std::shared_ptr<Cord> weasels = std::make_shared<Cord>("weasels");
  std::shared_ptr<Cord> cheeseweasels = std::make_shared<Cord>(cheese, weasels);
  /*
  std::cout << three.GetLeft()->GetData() << std::endl;
  std::cout << three.GetRight()->GetData() << std::endl;
  std::cout << three.Length() << std::endl;
  */
  std::cout << "\n" << std::endl;
  std::shared_ptr<Cord> tester = std::make_shared<Cord>("tester");
  std::shared_ptr<Cord> bigboss = std::make_shared<Cord>("bigboss");
  std::shared_ptr<Cord> testerbigboss = std::make_shared<Cord>(tester, bigboss);

  std::shared_ptr<Cord> combined =
      std::make_shared<Cord>(cheeseweasels, tester);

  std::shared_ptr<Cord> bigger =
      std::make_shared<Cord>(combined, testerbigboss);

  std::shared_ptr<Cord> giant = std::make_shared<Cord>(bigger, cheeseweasels);

  std::shared_ptr<Cord> thing = std::make_shared<Cord>(weasels, nullptr);

  /*
  Cord to_add("tester");
  Cord to_add_two("bigboss");
  std::shared_ptr<Cord> p4 = std::make_shared<Cord>(to_add.GetData());
  std::shared_ptr<Cord> p5 = std::make_shared<Cord>(to_add_two.GetData());
  // Cord four(p4, p5);
  std::shared_ptr<Cord> four = std::make_shared<Cord>(p4, p5);
  std::shared_ptr<Cord> combine = ConcatCords(p2, four);
  */

  std::shared_ptr<Cord> cord_2 = std::make_shared<Cord>("CS 12");
  std::shared_ptr<Cord> cord_4 = std::make_shared<Cord>("8 is awe");
  std::shared_ptr<Cord> cord_3 = std::make_shared<Cord>(cord_4, nullptr);
  std::shared_ptr<Cord> cord_1 = std::make_shared<Cord>(cord_2, cord_3);

  std::cout << cord_2->ToString() << std::endl;
  std::cout << cord_4->ToString() << std::endl;
  std::cout << cord_3->ToString() << std::endl;
  std::cout << cord_1->ToString() << std::endl;

  /*
  std::cout << cheeseweasels->At(9) << std::endl;
  std::cout << bigger->At(25) << std::endl;
  std::cout << "\n" << std::endl;
  std::cout << cheeseweasels->ToString() << std::endl;
  std::cout << testerbigboss->ToString() << std::endl;
  std::cout << bigger->ToString() << std::endl;
  std::cout << giant->ToString() << std::endl;
  std::cout << combined->ToString() << std::endl;
  std::cout << thing->ToString() << std::endl;

  */

  /*

  Cord three(p1, p2);
  std::cout << three.GetData() << std::endl;
  */

  return 0;
}
