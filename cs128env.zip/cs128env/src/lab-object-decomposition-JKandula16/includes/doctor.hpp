#ifndef DOCTOR_HPP
#define DOCTOR_HPP

#include <set>
#include <string>
#include <vector>

#include "schedule.hpp"

class Doctor {
public:
  Doctor() = default;
  void AddAppointment(TimeSlot time, std::string patient);
  void AddAppointment(TimeSlot time);
  void RemoveAppointment(TimeSlot time);
  void RemoveAppointment(TimeSlot time, std::string patient);
  bool IsAvailable(TimeSlot time) const;

private:
  Schedule schedule_;
};

#endif