#include "news_agent.hpp"

// no need to modify this function
NewsAgent::NewsAgent(): location_(nullptr) {}

// no need to modify this function
void NewsAgent::ChangeLocation(Location* loc) {
  if (location_) {
    location_->RemoveAgent(this);
  }

  location_ = loc;

  if (location_) {
    location_->AddAgent(this);
  }
}

void NewsAgent::AddNewsChannelClient(NewsChannel* client) {
  // TODO : implement
  channels_.push_back(client);
}

void NewsAgent::RemoveNewsChannelClient(NewsChannel* client) {
  // TODO : implement
  for (size_t i = 0; i < channels_.size(); ++i) {
    if (channels_.at(i) == client) {
      channels_.erase(channels_.begin() + i);
    }
  }
}

void NewsAgent::NotifyNews(std::string date,
                           std::string subject,
                           std::string action) {
  News news{location_->GetName(), date, subject, action};
  // TODO : implement
  for (auto* observer : channels_) {
    observer->NotifyNews(news);
  }
}