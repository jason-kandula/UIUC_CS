#include "news_agent.hpp"

// no need to modify this function
Location::Location(std::string name): name_(name) {}

// no need to modify this function
std::string Location::GetName() const { return name_; }

void Location::AddAgent(NewsAgent* agent) {
  // TODO : implement
  agents_.push_back(agent);
}

void Location::RemoveAgent(NewsAgent* agent) {
  // TODO : implement
  for (size_t i = 0; i < agents_.size(); ++i) {
    if (agents_.at(i) == agent) {
      agents_.erase(agents_.begin() + i);
    }
  }
}

void Location::Event(std::string date,
                     std::string subject,
                     std::string action) {
  // TODO : implement
  for (auto* observer : agents_) {
    observer->NotifyNews(date, subject, action);
  }
}
