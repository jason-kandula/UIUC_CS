#ifndef CATCH_CONFIG_MAIN
#  define CATCH_CONFIG_MAIN
#endif

#include "catch.hpp"
#include "informative_channel.hpp"
#include "news_agent.hpp"

/**
 * Remember that you can use stringstream to test output!
 */

TEST_CASE( "Your test case", "[test1]" ) {}
