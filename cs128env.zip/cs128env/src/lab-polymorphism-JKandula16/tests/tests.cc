#ifndef CATCH_CONFIG_MAIN
#  define CATCH_CONFIG_MAIN
#endif

#include "bathroom.hpp"
#include "catch.hpp"
#include "kitchen.hpp"
#include "living-room.hpp"
#include "room.hpp"

TEST_CASE( "Your tests", "[test1]" ) {}