#include <iostream>
#include <string>

#include "bathroom.hpp"
#include "kitchen.hpp"
#include "living-room.hpp"
#include "room.hpp"

void PrintVec(std::vector<std::string> vec) {
  std::cout << "[ ";
  for (std::string s : vec) {
    std::cout << "'" << s << "' ";
  }
  std::cout << "]" << std::endl;
}

/* As you begin to develop Room, uncomment below */
void PrintRoomContents(const Room& room) {
  std::cout << "People in " << room.GetName() << ": ";
  PrintVec(room.GetPeople());
}

int main() {
  Bathroom bathroom;
  Room& rb = bathroom;

  PrintRoomContents(rb);
  rb.AddPerson("Steve");
  PrintRoomContents(rb);
  rb.AddPerson("Andy");
  PrintRoomContents(rb);
  rb.RemovePerson("Andy");
  PrintRoomContents(rb);
  rb.RemovePerson("Steve");
  PrintRoomContents(rb);

  Kitchen kitchen;
  Room& rk = kitchen;

  rk.AddPerson("Helen");
  rk.AddPerson("Mia");
  rk.AddPerson("jacob");
  rk.AddPerson("hola");
  rk.AddPerson("cheese");
  rk.AddPerson("bobby");
  PrintRoomContents(rk);
  rk.RemovePerson("Mia");
  PrintRoomContents(rk);

  LivingRoom living_room;
  Room& rl = living_room;

  rl.AddPerson("Alex");
  rl.AddPerson("Daniel");
  rl.AddPerson("chese");
  rl.AddPerson("bob");
  rl.AddPerson("ksi");
  rl.AddPerson("jason");
  PrintRoomContents(rl);
  rl.RemovePerson("Alex");
  PrintRoomContents(rl);
}