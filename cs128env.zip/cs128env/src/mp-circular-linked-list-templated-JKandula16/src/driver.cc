#include <iostream>

#include "circular-linked-list.hpp"

int main() {
  CircularLinkedList<int> test;
  test.PushBack(5);
  test.PushBack(13);
  test.PushBack(17);
  test.PushBack(26);
  test.PushBack(34);
  test.PushBack(38);
  std::cout << test << std::endl;
  test.InsertInOrder(20);
  test.InsertInOrder(7);
  test.InsertInOrder(30);
  std::cout << test << std::endl;
  test.InsertInOrder(26);
  std::cout << test << std::endl;
  std::cout << "\n" << std::endl;

  CircularLinkedList<int> testing;
  testing.PushBack(40);
  CircularLinkedList<int> test2(testing);
  std::cout << test2 << std::endl;

  CircularLinkedList<int> test3 = test2;
  std::cout << test3 << std::endl;
  std::cout << "\n" << std::endl;

  CircularLinkedList<int> test5;
  test5.InsertInOrder(5);
  test5.InsertInOrder(6);
  test5.InsertInOrder(9);
  test5.InsertInOrder(3);
  test5.InsertInOrder(2);
  test5.InsertInOrder(1);
  std::cout << test5 << std::endl;
  std::cout << test5.GetHead()->data << std::endl;
  std::cout << test5.GetTail()->data << std::endl;
  std::cout << "\n" << std::endl;
  // order is descending now
  test5.Reverse();
  std::cout << test5 << std::endl;
  std::cout << test5.GetHead()->data << std::endl;
  std::cout << test5.GetTail()->data << std::endl;
  std::cout << "\n" << std::endl;
}
