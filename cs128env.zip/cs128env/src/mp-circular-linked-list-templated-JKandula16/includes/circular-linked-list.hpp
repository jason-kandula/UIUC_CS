#ifndef CIRCULAR_LINKED_LIST_HPP
#define CIRCULAR_LINKED_LIST_HPP

#include <iostream>

#include "node.hpp"

enum class Order { kASC, kDESC };

template <typename T>
class CircularLinkedList {
public:
  CircularLinkedList() = default;
  CircularLinkedList(const CircularLinkedList<T>& source);
  CircularLinkedList<T>& operator=(const CircularLinkedList<T>& source);
  ~CircularLinkedList();

  void InsertInOrder(const T& data);
  void Reverse();
  void PushBack(T value);
  Order GetNodeOrder();
  Node<T>* GetHead();
  Node<T>* GetTail();

  template <typename U>
  friend std::ostream& operator<<(std::ostream& os,
                                  const CircularLinkedList<U>& cll);

private:
  Node<T>* head_ = nullptr;
  Node<T>* tail_ = nullptr;
  Order node_order_ = Order::kASC;

  void InitLinkedList(const CircularLinkedList<T>& source);
  void Clear();
  void InsertInOrderAscending(const T& data);
  void InsertInOrderDescending(const T& data);
};

template <typename T>
std::ostream& operator<<(std::ostream& os, const CircularLinkedList<T>& cll) {
  Node<T>* iter = cll.head_;
  // empty list condition
  if (iter == nullptr) {
    os << "Empty list";
    return os;
  }
  // non-empty list condition
  do {
    os << iter->data << '\t';
    iter = iter->next;
  } while (iter != cll.head_);

  return os;
}
// functions for testing
template <typename T>
void CircularLinkedList<T>::PushBack(T value) {
  if (head_ == nullptr && tail_ == nullptr) {
    head_ = tail_ = new Node<T>(value);
    tail_->next = head_;
  } else {
    // use auto or Node<T>*??
    auto temp = new Node<T>(value);
    tail_->next = temp;
    tail_ = temp;
    tail_->next = head_;
  }
}

template <typename T>
Order CircularLinkedList<T>::GetNodeOrder() {
  return node_order_;
}

template <typename T>
Node<T>* CircularLinkedList<T>::GetTail() {
  return tail_;
}

template <typename T>
Node<T>* CircularLinkedList<T>::GetHead() {
  return head_;
}

// helper functions
template <typename T>
void CircularLinkedList<T>::InitLinkedList(
    const CircularLinkedList<T>& source) {
  // something probably wrong here
  node_order_ = source.node_order_;

  // head stuff
  Node<T>* current_source = source.head_;
  head_ = new Node<T>(source.head_->data);
  head_->next = nullptr;
  Node<T>* og_current = head_;

  current_source = current_source->next;

  // everything else stuff
  while (current_source != source.head_) {
    og_current->next = new Node<T>(current_source->data);
    og_current = og_current->next;
    if (current_source->next == source.head_) {
      tail_ = og_current;
      tail_->next = head_;
    } else {
      og_current->next = nullptr;
    }
    current_source = current_source->next;
  }
}

template <typename T>
void CircularLinkedList<T>::Clear() {
  if (head_ == nullptr && tail_ == nullptr) {
    // do nothing, since the list is already empty
    return;
  }
  if (head_ == tail_) {
    delete head_;
    head_ = nullptr;
    tail_ = nullptr;
  } else {
    tail_->next = nullptr;
    while (head_ != nullptr) {
      Node<T>* next_node = head_->next;
      delete head_;
      head_ = next_node;
    }
  }

  /*
  if (head_ == nullptr && tail_ == nullptr) {
    // do nothing, since the list is already empty
    return;
  }
  if (head_ == tail_) {
    delete head_;
    head_ = nullptr;
    tail_ = nullptr;
  } else {
    Node<T>*next_node = nullptr, *og_head = head_, *og_current = head_;
    while (og_current->next != og_head) {
      og_current = og_current->next;
      next_node = head_->next;
      delete head_;
      head_ = next_node;
    }
    delete head_;
    // not sure about this below
    head_ = nullptr;
  }
  */
}

template <typename T>
void CircularLinkedList<T>::InsertInOrderAscending(const T& data) {
  auto temp = new Node<T>(data);
  Node<T>* current = head_;
  Node<T>* post_current = head_->next;
  while (post_current != head_ && (post_current->data <= data)) {
    current = current->next;
    post_current = post_current->next;
  }
  temp->next = post_current;
  current->next = temp;

  if (temp->next == head_) {
    tail_ = temp;
  }
  // also make sure to update head and tail, (do head beforehand)
}

template <typename T>
void CircularLinkedList<T>::InsertInOrderDescending(const T& data) {
  auto temp = new Node<T>(data);
  temp->next = nullptr;
  Node<T>* current = head_;
  Node<T>* post_current = head_->next;
  while (post_current != head_ && (post_current->data >= data)) {
    current = current->next;
    post_current = post_current->next;
  }
  temp->next = post_current;
  current->next = temp;

  if (temp->next == head_) {
    tail_ = temp;
  }
  // same, update head and tail (do head beforehand)
}

// function definitions
template <typename T>
CircularLinkedList<T>::CircularLinkedList(const CircularLinkedList<T>& source) {
  if (source.head_ == nullptr && source.tail_ == nullptr) {
    head_ = nullptr;
    tail_ = nullptr;
    node_order_ = source.node_order_;
  } else if (source.head_ == source.tail_) {
    head_ = new Node<T>(source.head_->data);
    tail_ = head_;
    tail_->next = head_;

    node_order_ = source.node_order_;
  } else {
    node_order_ = source.node_order_;
    InitLinkedList(source);
  }
}

template <typename T>
CircularLinkedList<T>& CircularLinkedList<T>::operator=(
    const CircularLinkedList<T>& source) {
  if (this == &source) {
    return *this;
  }
  Clear();
  node_order_ = source.node_order_;
  // edge cases where source has 0 nodes or only has 1 node
  // not sure if this is right
  if (source.head_ == nullptr && source.tail_ == nullptr) {
    head_ = nullptr;
    tail_ = nullptr;
    // not sure about below
  } else if (source.head_ == source.tail_) {
    // not too sure about this either
    head_ = new Node<T>(source.head_->data);
    tail_ = head_;
    tail_->next = head_;
  } else {
    InitLinkedList(source);
  }
  return *this;
}

template <typename T>
CircularLinkedList<T>::~CircularLinkedList() {
  Clear();
}

template <typename T>
void CircularLinkedList<T>::InsertInOrder(const T& data) {
  if (node_order_ == Order::kASC) {
    if (head_ == nullptr || head_->data > data) {
      auto temp = new Node<T>(data);
      temp->next = nullptr;
      if (head_ == nullptr) {
        head_ = temp;
        tail_ = temp;
        tail_->next = head_;
      } else {
        temp->next = head_;
        head_ = temp;
        // not sure about this, i'm trying to set tail's next to the new head
        tail_->next = head_;
      }
    } else {
      InsertInOrderAscending(data);
    }
  } else {
    if (head_ == nullptr || head_->data < data) {
      auto temp = new Node<T>(data);
      temp->next = nullptr;
      if (head_ == nullptr) {
        head_ = temp;
        tail_ = temp;
        tail_->next = head_;
      } else {
        temp->next = head_;
        head_ = temp;
        // not sure about this, i'm trying to set tail's next to the new head
        tail_->next = head_;
      }
    } else {
      InsertInOrderDescending(data);
    }
  }
}

template <typename T>
void CircularLinkedList<T>::Reverse() {
  // should be toggling always
  if (node_order_ == Order::kASC) {
    node_order_ = Order::kDESC;
  } else {
    node_order_ = Order::kASC;
  }
  if (head_ != nullptr && tail_ != nullptr && head_ != tail_) {
    // previous pointer from MP help session slides
    Node<T>* previous_node = head_;
    Node<T>* og_head = head_;
    Node<T>* current = head_->next;
    head_ = current;
    while (head_ != og_head) {
      head_ = head_->next;
      current->next = previous_node;
      previous_node = current;
      current = head_;
    }
    // head is now back to its og place
    // now set tail
    current->next = previous_node;
    head_ = previous_node;
    Node<T>* new_it = head_;
    while (new_it->next != head_) {
      new_it = new_it->next;
    }
    tail_ = new_it;
  } else {
    return;
  }
}

#endif