#include "seam_carver.hpp"

// implement the rest of SeamCarver's functions here
const ImagePPM& SeamCarver::GetImage() const { return image_; }

int SeamCarver::GetHeight() const { return height_; }

int SeamCarver::GetWidth() const { return width_; }

int SeamCarver::EnergyHelperNorm(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;
  // take difference in adjacent row values, (so col changes here)
  red1 = image_.GetPixel(row, col - 1).GetRed() -
         image_.GetPixel(row, col + 1).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, col - 1).GetGreen() -
           image_.GetPixel(row, col + 1).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, col - 1).GetBlue() -
          image_.GetPixel(row, col + 1).GetBlue();
  blue1 = blue1 * blue1;

  // take difference in adjacent col values (so row changes here)
  red2 = image_.GetPixel(row - 1, col).GetRed() -
         image_.GetPixel(row + 1, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(row - 1, col).GetGreen() -
           image_.GetPixel(row + 1, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(row - 1, col).GetBlue() -
          image_.GetPixel(row + 1, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::EdgeEnergyHelperFirstRow(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;

  red1 = image_.GetPixel(row, col - 1).GetRed() -
         image_.GetPixel(row, col + 1).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, col - 1).GetGreen() -
           image_.GetPixel(row, col + 1).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, col - 1).GetBlue() -
          image_.GetPixel(row, col + 1).GetBlue();
  blue1 = blue1 * blue1;

  red2 = image_.GetPixel(image_.GetHeight() - 1, col).GetRed() -
         image_.GetPixel(row + 1, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(image_.GetHeight() - 1, col).GetGreen() -
           image_.GetPixel(row + 1, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(image_.GetHeight() - 1, col).GetBlue() -
          image_.GetPixel(row + 1, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::EdgeEnergyHelperLastRow(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;

  red1 = image_.GetPixel(row, col - 1).GetRed() -
         image_.GetPixel(row, col + 1).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, col - 1).GetGreen() -
           image_.GetPixel(row, col + 1).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, col - 1).GetBlue() -
          image_.GetPixel(row, col + 1).GetBlue();
  blue1 = blue1 * blue1;

  red2 =
      image_.GetPixel(row - 1, col).GetRed() - image_.GetPixel(0, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(row - 1, col).GetGreen() -
           image_.GetPixel(0, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(row - 1, col).GetBlue() -
          image_.GetPixel(0, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::FirstColEdgeEnergyHelper(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;

  red1 = image_.GetPixel(row, image_.GetWidth() - 1).GetRed() -
         image_.GetPixel(row, col + 1).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, image_.GetWidth() - 1).GetGreen() -
           image_.GetPixel(row, col + 1).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, image_.GetWidth() - 1).GetBlue() -
          image_.GetPixel(row, col + 1).GetBlue();
  blue1 = blue1 * blue1;

  red2 = image_.GetPixel(row - 1, col).GetRed() -
         image_.GetPixel(row + 1, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(row - 1, col).GetGreen() -
           image_.GetPixel(row + 1, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(row - 1, col).GetBlue() -
          image_.GetPixel(row + 1, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::LastColEdgeEnergyHelper(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;

  red1 =
      image_.GetPixel(row, col - 1).GetRed() - image_.GetPixel(row, 0).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, col - 1).GetGreen() -
           image_.GetPixel(row, 0).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, col - 1).GetBlue() -
          image_.GetPixel(row, 0).GetBlue();
  blue1 = blue1 * blue1;

  red2 = image_.GetPixel(row - 1, col).GetRed() -
         image_.GetPixel(row + 1, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(row - 1, col).GetGreen() -
           image_.GetPixel(row + 1, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(row - 1, col).GetBlue() -
          image_.GetPixel(row + 1, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::TopLeftCorner(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;
  // take difference in adjacent row values, (so col changes here)
  red1 = image_.GetPixel(row, image_.GetWidth() - 1).GetRed() -
         image_.GetPixel(row, col + 1).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, image_.GetWidth() - 1).GetGreen() -
           image_.GetPixel(row, col + 1).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, image_.GetWidth() - 1).GetBlue() -
          image_.GetPixel(row, col + 1).GetBlue();
  blue1 = blue1 * blue1;

  // take difference in adjacent col values (so row changes here)
  red2 = image_.GetPixel(image_.GetHeight() - 1, col).GetRed() -
         image_.GetPixel(row + 1, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(image_.GetHeight() - 1, col).GetGreen() -
           image_.GetPixel(row + 1, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(image_.GetHeight() - 1, col).GetBlue() -
          image_.GetPixel(row + 1, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::TopRightCorner(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;
  // take difference in adjacent row values, (so col changes here)
  red1 =
      image_.GetPixel(row, col - 1).GetRed() - image_.GetPixel(row, 0).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, col - 1).GetGreen() -
           image_.GetPixel(row, 0).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, col - 1).GetBlue() -
          image_.GetPixel(row, 0).GetBlue();
  blue1 = blue1 * blue1;

  // take difference in adjacent col values (so row changes here)
  red2 = image_.GetPixel(image_.GetHeight() - 1, col).GetRed() -
         image_.GetPixel(row + 1, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(image_.GetHeight() - 1, col).GetGreen() -
           image_.GetPixel(row + 1, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(image_.GetHeight() - 1, col).GetBlue() -
          image_.GetPixel(row + 1, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::BottomLeftCorner(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;
  // take difference in adjacent row values, (so col changes here)
  red1 = image_.GetPixel(row, image_.GetWidth() - 1).GetRed() -
         image_.GetPixel(row, col + 1).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, image_.GetWidth() - 1).GetGreen() -
           image_.GetPixel(row, col + 1).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, image_.GetWidth() - 1).GetBlue() -
          image_.GetPixel(row, col + 1).GetBlue();
  blue1 = blue1 * blue1;

  // take difference in adjacent col values (so row changes here)
  red2 =
      image_.GetPixel(row - 1, col).GetRed() - image_.GetPixel(0, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(row - 1, col).GetGreen() -
           image_.GetPixel(0, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(row - 1, col).GetBlue() -
          image_.GetPixel(0, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::BottomRightCorner(int row, int col) const {
  int answer = 0;
  int red1 = 0;
  int green1 = 0;
  int blue1 = 0;
  int red2 = 0;
  int green2 = 0;
  int blue2 = 0;
  // take difference in adjacent row values, (so col changes here)
  red1 =
      image_.GetPixel(row, col - 1).GetRed() - image_.GetPixel(row, 0).GetRed();
  red1 = red1 * red1;

  green1 = image_.GetPixel(row, col - 1).GetGreen() -
           image_.GetPixel(row, 0).GetGreen();
  green1 = green1 * green1;

  blue1 = image_.GetPixel(row, col - 1).GetBlue() -
          image_.GetPixel(row, 0).GetBlue();
  blue1 = blue1 * blue1;

  // take difference in adjacent col values (so row changes here)
  red2 =
      image_.GetPixel(row - 1, col).GetRed() - image_.GetPixel(0, col).GetRed();
  red2 = red2 * red2;

  green2 = image_.GetPixel(row - 1, col).GetGreen() -
           image_.GetPixel(0, col).GetGreen();
  green2 = green2 * green2;

  blue2 = image_.GetPixel(row - 1, col).GetBlue() -
          image_.GetPixel(0, col).GetBlue();
  blue2 = blue2 * blue2;

  answer = red1 + red2 + green1 + green2 + blue1 + blue2;
  return answer;
}

int SeamCarver::GetEnergy(int row, int col) const {
  int energy = 0;
  if ((row > 0 && row < image_.GetHeight() - 1) &&
      (col > 0 && col < image_.GetWidth() - 1)) {
    energy = EnergyHelperNorm(row, col);
  } else if (row == 0 && col != 0 && col != image_.GetWidth() - 1) {
    energy = EdgeEnergyHelperFirstRow(row, col);
  } else if (row == image_.GetHeight() - 1 && col != 0 &&
             col != image_.GetWidth() - 1) {
    energy = EdgeEnergyHelperLastRow(row, col);
  } else if (col == 0 && row != 0 && row != image_.GetHeight() - 1) {
    energy = FirstColEdgeEnergyHelper(row, col);
  } else if (col == image_.GetWidth() - 1 && row != 0 &&
             row != image_.GetHeight() - 1) {
    energy = LastColEdgeEnergyHelper(row, col);
  } else if (row == 0 && col == 0) {
    energy = TopLeftCorner(row, col);
  } else if (row == 0 && col == image_.GetWidth() - 1) {
    energy = TopRightCorner(row, col);
  } else if (row == image_.GetHeight() - 1 && col == 0) {
    energy = BottomLeftCorner(row, col);
  } else if (row == image_.GetHeight() - 1 && col == image_.GetWidth() - 1) {
    energy = BottomRightCorner(row, col);
  }

  return energy;
}

int* SeamCarver::GetVerticalSeam() const {}

int* SeamCarver::GetHorizontalSeam() const { return nullptr; }

void SeamCarver::RemoveHorizontalSeam() {}

void SeamCarver::RemoveVerticalSeam() {}
// given functions below, DO NOT MODIFY

SeamCarver::SeamCarver(const ImagePPM& image): image_(image) {
  height_ = image.GetHeight();
  width_ = image.GetWidth();
}

void SeamCarver::SetImage(const ImagePPM& image) {
  image_ = image;
  width_ = image.GetWidth();
  height_ = image.GetHeight();
}
