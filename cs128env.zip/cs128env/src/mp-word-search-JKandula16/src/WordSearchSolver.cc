#include "WordSearchSolver.hpp"

// constructor
WordSearchSolver::WordSearchSolver(
    const std::vector<std::vector<char>>& puzzle) {
  for (size_t i = 0; i < puzzle.size(); ++i) {
    puzzle_.push_back(puzzle.at(i));
  }
  puzzle_height_ = puzzle.size();
  puzzle_width_ = (puzzle.at(0)).size();
}

// helper function for horizontal search
WordLocation WordSearchSolver::HorizontalSearch(const std::string& word) {
  size_t count = 0;
  int index = 0;
  std::vector<CharPositions> ans1;
  WordLocation ans2;
  for (size_t i = 0; i < puzzle_height_; ++i) {
    count = 0;
    index = 0;
    for (size_t j = 0; j < puzzle_width_; ++j) {
      if (puzzle_.at(i).at(j) == word.at(index)) {
        CharPositions temp = {word.at(index), i, j};
        ans1.push_back(temp);
        index++;
        count++;
        if (count == word.size()) {
          ans2 = {word, ans1};
          break;
        }

      } else {
        count = 0;
        index = 0;
        ans1.clear();
      }
    }
    if (count == word.size()) {
      ans2 = {word, ans1};
      return ans2;
    }
  }
  return WordLocation{};
}

// helper function for vertical search
WordLocation WordSearchSolver::VerticalSearch(const std::string& word) {
  size_t count = 0;
  int index = 0;
  std::vector<CharPositions> ans1;
  WordLocation ans2;
  for (size_t i = 0; i < puzzle_width_; ++i) {
    count = 0;
    index = 0;
    for (size_t j = 0; j < puzzle_height_; ++j) {
      if (puzzle_.at(j).at(i) == word.at(index)) {
        CharPositions temp = {word.at(index), j, i};
        ans1.push_back(temp);
        index++;
        count++;
        if (count == word.size()) {
          ans2 = {word, ans1};
          break;
        }

      } else {
        if (puzzle_.at(j).at(i) == word.at(0) && j < (puzzle_height_ - 1)) {
          j--;
        }
        index = 0;
        count = 0;
        ans1.clear();
      }
    }
    if (count == word.size()) {
      ans2 = {word, ans1};
      return ans2;
    }
  }
  return WordLocation{};
}

// helper function for right diagonal
WordLocation WordSearchSolver::RightDiagSearch(const std::string& word) {
  int index = 0;
  size_t row = 0, col = 0, count = 0;
  std::vector<CharPositions> ans1;
  WordLocation ans2;
  for (size_t i = 0; i < puzzle_height_; ++i) {
    count = 0, index = 0;
    for (size_t j = 0; j < puzzle_width_; ++j) {
      row = i;
      col = j;
      for (size_t k = 0; k < word.size(); ++k) {
        if (!LocationInBounds(row, col)) {
          index = 0;
          count = 0;
          break;
        }
        if (puzzle_.at(row).at(col) == word.at(index)) {
          CharPositions temp = {word.at(index), row, col};
          ans1.push_back(temp);
          index++;
          count++;
          row++;
          col++;
          if (count == word.size()) {
            ans2 = {word, ans1};
            return ans2;
          }
        } else {
          count = 0;
          index = 0;
          ans1.clear();
        }
      }
    }
    if (count == word.size()) {
      ans2 = {word, ans1};
      return ans2;
    }
  }
  return WordLocation{};
}

// helper function for left diagonal
WordLocation WordSearchSolver::LeftDiagSearch(const std::string& word) {
  int index = 0;
  size_t row = 0, col = 0, count = 0;
  std::vector<CharPositions> ans1;
  WordLocation ans2;
  for (size_t i = 0; i < puzzle_height_; ++i) {
    count = 0, index = 0;
    for (size_t j = puzzle_width_ - 1; j != std::numeric_limits<size_t>::max();
         --j) {
      row = i, col = j;
      for (size_t k = 0; k < word.size(); ++k) {
        if (!LocationInBounds(row, col)) {
          index = 0, count = 0;
          break;
        }
        if (puzzle_.at(row).at(col) == word.at(index)) {
          CharPositions temp = {word.at(index), row, col};
          ans1.push_back(temp);
          index++;
          count++;
          row++;
          col--;
          if (count == word.size()) {
            ans2 = {word, ans1};
            return ans2;
          }
        } else {
          count = 0, index = 0;
          ans1.clear();
        }
      }
    }
    if (count == word.size()) {
      ans2 = {word, ans1};
      return ans2;
    }
  }
  return WordLocation{};
}

// FindWord with specified direction
WordLocation WordSearchSolver::FindWord(const std::string& word,
                                        CheckDirection direction) {
  if (word.size() > puzzle_height_ || word.size() > puzzle_width_) {
    return WordLocation{};
  }
  if (direction == CheckDirection::kHorizontal) {
    return HorizontalSearch(word);
  }
  if (direction == CheckDirection::kVertical) {
    return VerticalSearch(word);
  }
  if (direction == CheckDirection::kLeftDiag) {
    return LeftDiagSearch(word);
  }
  if (direction == CheckDirection::kRightDiag) {
    return RightDiagSearch(word);
  }
  return WordLocation{};
}

// FindWord for all directions, in general
WordLocation WordSearchSolver::FindWord(const std::string& word) {
  if (word.size() > puzzle_height_ || word.size() > puzzle_width_) {
    return WordLocation{};
  }

  WordLocation ans1 = FindWord(word, CheckDirection::kHorizontal);
  WordLocation ans2 = FindWord(word, CheckDirection::kVertical);
  WordLocation ans3 = FindWord(word, CheckDirection::kLeftDiag);
  WordLocation ans4 = FindWord(word, CheckDirection::kRightDiag);

  if (!ans1.char_positions.empty()) {
    return ans1;
  }
  if (!ans2.char_positions.empty()) {
    return ans2;
  }
  if (!ans3.char_positions.empty()) {
    return ans3;
  }
  if (!ans4.char_positions.empty()) {
    return ans4;
  }

  // put this in later as the default answer, if the others all fail
  return WordLocation{};
}

// given
bool WordSearchSolver::LocationInBounds(size_t row, size_t col) const {
  return ((row < puzzle_height_) && (col < puzzle_width_));
}
