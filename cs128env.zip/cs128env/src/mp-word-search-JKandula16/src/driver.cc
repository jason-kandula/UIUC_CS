#include <iostream>
#include <string>
#include <vector>

#include "WordSearchSolver.hpp"

int main() {
  std::vector<std::vector<char>> tester{{'c', 'e', 'd', 'a', 'v'},
                                        {'f', 'a', 'd', 'q', 'c'},
                                        {'m', 'w', 'c', 'a', 'm'},
                                        {'a', 'a', 'v', 'a', 'u'},
                                        {'t', 'e', 'r', 'o', 'u'}};
  WordSearchSolver test(tester);
  WordLocation test_answer = test.FindWord("cat", CheckDirection::kLeftDiag);
  WordLocation test_answer_two = test.FindWord("cat");
  std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

  std::vector<CharPositions> checker = {{'c', 2, 2}, {'a', 3, 1}, {'t', 4, 0}};
  WordLocation checker_two = {"cat", checker};

  std::cout << test_answer << std::endl;
  std::cout << checker_two << std::endl;

  /*
  std::vector<std::vector<char>> puzzle{{'d', 'e', 'c', 'a', 't'},
                                        {'h', 'e', 'l', 'l', 'o'},
                                        {'c', 'a', 'l', 'o', 'm'},
                                        {'a', 'e', 't', 'a', 'u'},
                                        {'t', 'e', 't', 'o', 'u'}};
  // WordSearchSolver wss(puzzle);
  // std::cout << wss.FindWord("hello", CheckDirection::kHorizontal);
  // std::cout << wss.FindWord("hello");
  */
}