// clang-format off
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
//  Written By : Student Name                    Environment : ubuntu:bionic               //
//  Date ......: 2021/02/10                      Compiler ...: clang-10                    //
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
// clang-format on
/////////////////////////////////////////////////////////////////////////////////////////////
//                             Framework Set-up //
/////////////////////////////////////////////////////////////////////////////////////////////
#include "catch.hpp"

/////////////////////////////////////////////////////////////////////////////////////////////
//                                 Includes //
/////////////////////////////////////////////////////////////////////////////////////////////
#include <stdexcept>

#include "CharPositions.hpp"
#include "WordLocation.hpp"
#include "WordSearchSolver.hpp"

/////////////////////////////////////////////////////////////////////////////////////////////
//                             Helpers/Constants //
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
//                                Test Cases //
/////////////////////////////////////////////////////////////////////////////////////////////

TEST_CASE("constructor test", "initialize 2D vector") {
  SECTION("initializing puzzle vector") {
    std::vector<std::vector<char>> tester{{'d', 'e', 'a', 'o', 'u'},
                                          {'h', 'e', 'l', 'l', 'o'},
                                          {'c', 'a', 'l', 'o', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'t', 'e', 't', 'o', 'u'}};
    WordSearchSolver test(tester);
    int check = 0;
    for (size_t i = 0; i < tester.size(); ++i) {
      for (size_t j = 0; j < tester.at(i).size(); ++j) {
        if ((tester.at(i).at(j)) != (tester.at(i).at(j))) {
          check++;
        }
      }
    }
    REQUIRE(check == 0);
  }
}

TEST_CASE("horizontal search using specified direction FindWord",
          "hor search") {
  SECTION("test with first row") {
    std::vector<std::vector<char>> tester{{'d', 'e', 'c', 'a', 't'},
                                          {'h', 'e', 'l', 'l', 'o'},
                                          {'c', 'a', 'l', 'o', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'t', 'e', 't', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer =
        test.FindWord("cat", CheckDirection::kHorizontal);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 0, 2}, {'a', 0, 3}, {'t', 0, 4}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
  SECTION("test with second row") {
    // made the first row ALMOST correct, but not quite
    std::vector<std::vector<char>> tester{{'h', 'e', 'l', 'l', 't'},
                                          {'h', 'e', 'l', 'l', 'o'},
                                          {'c', 'a', 'l', 'o', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'t', 'e', 't', 'o', 'u'}};
    WordSearchSolver test(tester);

    WordLocation test_answer =
        test.FindWord("hello", CheckDirection::kHorizontal);
    WordLocation test_answer_two = test.FindWord("hello");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'h', 1, 0}, {'e', 1, 1}, {'l', 1, 2}, {'l', 1, 3}, {'o', 1, 4}};
    WordLocation checker_two = {"hello", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
}

TEST_CASE("more horizontal test cases", "hor search") {
  SECTION("test with horizontal edge case") {
    std::vector<std::vector<char>> tester{{'h', 'e', 'l', 'l', 't'},
                                          {'a', 'd', 'o', 'o', 'r'},
                                          {'c', 'a', 'l', 'o', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'t', 'e', 't', 'o', 'u'}};
    WordSearchSolver test(tester);

    WordLocation test_answer =
        test.FindWord("door", CheckDirection::kHorizontal);
    WordLocation test_answer_two = test.FindWord("door");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'d', 1, 1}, {'o', 1, 2}, {'o', 1, 3}, {'r', 1, 4}};
    WordLocation checker_two = {"door", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
}

TEST_CASE("vertical search using specified direction FindWord", "ver search") {
  SECTION("test with first column") {
    std::vector<std::vector<char>> tester{{'e', 'e', 'c', 'q', 't'},
                                          {'f', 'e', 'l', 'l', 'o'},
                                          {'c', 'a', 'l', 'o', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'t', 'e', 't', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kVertical);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 2, 0}, {'a', 3, 0}, {'t', 4, 0}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }

  SECTION("test with middle column") {
    std::vector<std::vector<char>> tester{{'e', 'e', 'h', 'a', 't'},
                                          {'f', 'e', 'e', 'l', 'o'},
                                          {'c', 'a', 'l', 'o', 'm'},
                                          {'a', 'e', 'l', 'a', 'u'},
                                          {'r', 'e', 'o', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer =
        test.FindWord("hello", CheckDirection::kVertical);
    WordLocation test_answer_two = test.FindWord("hello");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'h', 0, 2}, {'e', 1, 2}, {'l', 2, 2}, {'l', 3, 2}, {'o', 4, 2}};
    WordLocation checker_two = {"hello", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
}

TEST_CASE("more vertical tests cases ", "ver search") {
  SECTION("test with vertical edge case") {
    std::vector<std::vector<char>> tester{{'e', 'e', 'd', 'a', 't'},
                                          {'f', 'e', 'd', 'l', 'o'},
                                          {'c', 'a', 'o', 'o', 'm'},
                                          {'a', 'e', 'o', 'a', 'u'},
                                          {'r', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("door", CheckDirection::kVertical);
    WordLocation test_answer_two = test.FindWord("door");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'d', 1, 2}, {'o', 2, 2}, {'o', 3, 2}, {'r', 4, 2}};
    WordLocation checker_two = {"door", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
  SECTION("test case with all d's for the word door") {
    std::vector<std::vector<char>> tester{{'e', 'e', 'd', 'a', 't'},
                                          {'f', 'e', 'd', 'l', 'o'},
                                          {'c', 'a', 'd', 'o', 'm'},
                                          {'a', 'e', 'd', 'a', 'u'},
                                          {'r', 'e', 'd', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("door", CheckDirection::kVertical);
    WordLocation test_answer_two = test.FindWord("door");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'d', 1, 2}, {'o', 2, 2}, {'o', 3, 2}, {'r', 4, 2}};
    WordLocation checker_two = {"door", checker};
    REQUIRE(test_answer.word != checker_two.word);
    REQUIRE(test_answer_two.word != checker_two.word);
  }
}

TEST_CASE("Right diagonal", "r diag") {
  SECTION("basic test") {
    std::vector<std::vector<char>> tester{{'c', 'e', 'd', 'a', 't'},
                                          {'f', 'a', 'd', 'l', 'o'},
                                          {'c', 'a', 't', 'o', 'm'},
                                          {'a', 'e', 'o', 'a', 'u'},
                                          {'r', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kRightDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 0, 0}, {'a', 1, 1}, {'t', 2, 2}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
  SECTION("cat but starting at [0][1]") {
    std::vector<std::vector<char>> tester{{'z', 'c', 'd', 'a', 't'},
                                          {'f', 'q', 'a', 'l', 'o'},
                                          {'c', 'a', 's', 't', 'm'},
                                          {'a', 'e', 'o', 'a', 'u'},
                                          {'r', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kRightDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 0, 1}, {'a', 1, 2}, {'t', 2, 3}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
}

TEST_CASE("more right diagonal test cases", "r diag") {
  SECTION("cat but in the middle of the puzzle") {
    std::vector<std::vector<char>> tester{{'z', 'c', 'd', 'a', 't'},
                                          {'g', 'c', 'q', 'l', 'o'},
                                          {'c', 'w', 'a', 'v', 'm'},
                                          {'a', 'e', 't', 't', 'u'},
                                          {'r', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kRightDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 1, 1}, {'a', 2, 2}, {'t', 3, 3}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
  SECTION("cat but in the bottom right corner") {
    std::vector<std::vector<char>> tester{{'z', 'c', 'd', 'a', 't'},
                                          {'g', 'u', 'q', 'l', 'o'},
                                          {'c', 'w', 'c', 'v', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'r', 'e', 'r', 'o', 't'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kRightDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 2, 2}, {'a', 3, 3}, {'t', 4, 4}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
}
TEST_CASE("even more right diagonal test cases") {
  SECTION("cat but starting from second row") {
    std::vector<std::vector<char>> tester{{'z', 'c', 'd', 'a', 't'},
                                          {'c', 'q', 'q', 'l', 'o'},
                                          {'c', 'a', 's', 'v', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'r', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kRightDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 1, 0}, {'a', 2, 1}, {'t', 3, 2}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
  SECTION("looks for cat, but on the EDGE, with incomplete cat elsewhere") {
    std::vector<std::vector<char>> tester{{'z', 'c', 'd', 'c', 't'},
                                          {'c', 'q', 'a', 'l', 'a'},
                                          {'c', 'c', 's', 'v', 'm'},
                                          {'q', 'e', 'a', 'a', 't'},
                                          {'t', 'e', 'r', 't', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kRightDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 2, 1}, {'a', 3, 2}, {'t', 4, 3}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.char_positions.size() ==
            checker_two.char_positions.size());
    REQUIRE(test_answer_two.char_positions.size() ==
            checker_two.char_positions.size());
  }
}
TEST_CASE("Left diagonal testing", "left diag") {
  SECTION("basic test") {
    std::vector<std::vector<char>> tester{{'c', 'e', 'd', 'a', 'c'},
                                          {'f', 'a', 'd', 'a', 'o'},
                                          {'c', 'q', 't', 'o', 'm'},
                                          {'a', 'e', 'o', 'a', 'u'},
                                          {'r', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kLeftDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 0, 4}, {'a', 1, 3}, {'t', 2, 2}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
  SECTION("cat but left diag, down one") {
    std::vector<std::vector<char>> tester{{'c', 'e', 'd', 'a', 'v'},
                                          {'f', 'a', 'd', 'q', 'c'},
                                          {'c', 'q', 'w', 'a', 'm'},
                                          {'a', 'e', 't', 'a', 'u'},
                                          {'r', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kLeftDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 1, 4}, {'a', 2, 3}, {'t', 3, 2}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
}

TEST_CASE("more left diag testing", "left diag") {
  SECTION("cat but left diag, with almost complete word in there") {
    std::vector<std::vector<char>> tester{{'c', 'e', 'd', 'a', 'v'},
                                          {'f', 'a', 'd', 'q', 'c'},
                                          {'m', 'w', 'c', 'a', 'm'},
                                          {'a', 'a', 'v', 'a', 'u'},
                                          {'t', 'e', 'r', 'o', 'u'}};
    WordSearchSolver test(tester);
    WordLocation test_answer = test.FindWord("cat", CheckDirection::kLeftDiag);
    WordLocation test_answer_two = test.FindWord("cat");
    std::vector<CharPositions> test_answer_vector = test_answer.char_positions;

    std::vector<CharPositions> checker = {
        {'c', 2, 2}, {'a', 3, 1}, {'t', 4, 0}};
    WordLocation checker_two = {"cat", checker};
    REQUIRE(test_answer.word == checker_two.word);
    REQUIRE(test_answer_two.word == checker_two.word);
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////