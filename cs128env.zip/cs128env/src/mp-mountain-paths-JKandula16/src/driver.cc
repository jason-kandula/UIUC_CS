#include <iostream>

#include "elevation_dataset.hpp"
#include "path.hpp"

int main() {
  ElevationDataset thing =
      ElevationDataset("example-data/ex_input_data/prompt_5w_2h.dat", 2, 5);
  std::cout << thing.Width() << std::endl;
  std::cout << thing.Height() << std::endl;
  std::cout << "\n" << std::endl;
  for (size_t i = 0; i < thing.GetData().size(); ++i) {
    for (size_t j = 0; j < thing.GetData().at(i).size(); ++j) {
      std::cout << thing.GetData().at(i).at(j) << std::endl;
    }
    std::cout << "-" << std::endl;
  }
  std::cout << "\n" << std::endl;
  std::cout << thing.GetData().at(0).size() << std::endl;
  std::cout << thing.GetData().size() << std::endl;
  std::cout << "\n" << std::endl;
  std::cout << thing.MaxEle() << std::endl;
  std::cout << thing.MinEle() << std::endl;
}
