#include "path.hpp"

// Path constructor here
Path::Path(size_t length, size_t starting_row) {
  if (length < 0 || starting_row < 0) {
    throw std::out_of_range("out of range");
  }
  length_ = length;
  starting_row_ = starting_row;

  for (size_t i = 0; i < length; ++i) {
    path_.push_back(0);
  }
  // path_.size() = length;
  // or path_(length, 0);
}

size_t Path::Length() const { return length_; }

size_t Path::StartingRow() const { return starting_row_; }

unsigned int Path::EleChange() const { return ele_change_; }

void Path::IncEleChange(unsigned int value) {
  if (value < 0) {
    value = value * -1;
  }
  ele_change_ = ele_change_ + value;
}

const std::vector<size_t>& Path::GetPath() const { return path_; }

void Path::SetLoc(size_t col, size_t row) {
  // double check this, just in case,
  if (col >= length_ || row < 0) {
    throw std::out_of_range("out of range");
  }
  path_.at(col) = row;
}