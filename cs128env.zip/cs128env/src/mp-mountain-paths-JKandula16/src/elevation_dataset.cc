#include "elevation_dataset.hpp"

#include <fstream>
#include <iostream>

ElevationDataset::ElevationDataset(const std::string& filename,
                                   size_t width,
                                   size_t height) {
  width_ = width, height_ = height;
  max_ele_ = 0, min_ele_ = 0;
  size_t count = 0;
  std::vector<int> temp;
  std::ifstream ifs(filename);
  int value = 0;
  while (ifs.good()) {
    ifs >> value;
    if (ifs.bad()) {
      throw std::runtime_error("read unrecoverable error in file");
    }
    if (ifs.fail()) {
      if (ifs.eof()) {
        break;
      }
      ifs.clear();
      ifs.ignore(1, '\n');
    } else {
      count++;
      temp.push_back(value);
      if (count == 1) {
        max_ele_ = value, min_ele_ = value;
      } else if (value > max_ele_) {
        max_ele_ = value;
      }
      if (value < min_ele_) {
        min_ele_ = value;
      }
    }
  }
  if (count != (width_ * height_)) {
    throw std::runtime_error("error in number of data points");
  }
  std::vector<int> move;
  size_t i = 0;
  while (i < temp.size()) {
    if (move.size() < width_) {
      move.push_back(temp.at(i));
    } else if (move.size() == width_) {
      if (data_.size() < height_) {
        data_.push_back(move);
      } else if (data_.size() == height_) {
        break;
      }
      move = {};
    }
  }
  i++;
}
size_t ElevationDataset::Width() const { return width_; }
size_t ElevationDataset::Height() const { return height_; }
int ElevationDataset::MaxEle() const { return max_ele_; }
int ElevationDataset::MinEle() const { return min_ele_; }
int ElevationDataset::DatumAt(size_t row, size_t col) const {
  return data_.at(row).at(col);
}
const std::vector<std::vector<int>>& ElevationDataset::GetData() const {
  // PUT BACK IN CONSTRUCTOR
  /*
 if (temp.size() < width) {
         temp.push_back(value);
       } else if (temp.size() == width) {
         if (data_.size() < height) {
           data_.push_back(temp);
           temp = {};
         } else if (data_.size() == height) {
           if (count != (width * height)) {
             throw std::runtime_error("error in number of data points");
           }
         }
       }
  */
  return data_;
}