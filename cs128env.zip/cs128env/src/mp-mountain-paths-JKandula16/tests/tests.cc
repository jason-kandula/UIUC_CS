// clang-format off
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
//  Written By : Student Name                    Environment : ubuntu:bionic               //
//  Date ......: 2021/02/10                      Compiler ...: clang-10                    //
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
// clang-format on
/////////////////////////////////////////////////////////////////////////////////////////////
//                             Framework Set-up //
/////////////////////////////////////////////////////////////////////////////////////////////
#include "catch.hpp"

/////////////////////////////////////////////////////////////////////////////////////////////
//                                 Includes //
/////////////////////////////////////////////////////////////////////////////////////////////
#include <stdexcept>

#include "color.hpp"
#include "elevation_dataset.hpp"
#include "grayscale_image.hpp"
#include "path.hpp"
#include "path_image.hpp"

/////////////////////////////////////////////////////////////////////////////////////////////
//                             Helpers/Constants //
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
//                                Test Cases //
/////////////////////////////////////////////////////////////////////////////////////////////

TEST_CASE("Color class testing") {
  SECTION("default constructor check") {
    Color c = Color();
    REQUIRE(c.Red() == 0);
    REQUIRE(c.Green() == 0);
    REQUIRE(c.Blue() == 0);
  }
  SECTION("parameterized constructor check") {
    Color c = Color(1, 2, 3);
    REQUIRE(c.Red() == 1);
    REQUIRE(c.Green() == 2);
    REQUIRE(c.Blue() == 3);
  }
  SECTION("parameterized constructor check, out of bounds")
  REQUIRE_THROWS_AS(Color(0, 0, 256), std::out_of_range);
  REQUIRE_THROWS_AS(Color(-5, -2, 532), std::out_of_range);
}

TEST_CASE("Path class testing (default stuff)") {
  SECTION("constructor check") {
    Path test = Path(5, 3);
    REQUIRE(test.GetPath().size() == 5);
    REQUIRE(test.Length() == 5);
    REQUIRE(test.StartingRow() == 3);
  }
  SECTION("other functions of Path class") {
    // IncElec
    Path test = Path(3, 6);
    test.IncEleChange(11);
    REQUIRE(test.EleChange() == 11);
    test.IncEleChange(22);
    REQUIRE(test.EleChange() == 33);

    // SetLoc
    test.SetLoc(0, 17);
    REQUIRE(test.GetPath().at(0) == 17);
    test.SetLoc(1, 25);
    REQUIRE(test.GetPath().at(1) == 25);
    REQUIRE_THROWS_AS(test.SetLoc(-2, 100), std::out_of_range);
  }
}

TEST_CASE("ElevationDataset testing") {
  SECTION("constructor") {
    ElevationDataset test =
        ElevationDataset("example-data/ex_input_data/prompt_5w_2h.dat", 5, 2);
    REQUIRE(test.GetData().size() == 2);
    REQUIRE(test.GetData().at(0).size() == 5);
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////