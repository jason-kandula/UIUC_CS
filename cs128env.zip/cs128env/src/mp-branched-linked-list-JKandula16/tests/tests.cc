#include "catch.hpp"

#include "branched-linked-list.hpp"
 
TEST_CASE("Test Case", "[tag]") {
  REQUIRE(true == true);
}