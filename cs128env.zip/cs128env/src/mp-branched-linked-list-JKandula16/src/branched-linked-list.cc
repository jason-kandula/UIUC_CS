#include "branched-linked-list.hpp"

// helper functions
void BLL::Clear() {
  if (head_ == nullptr) {
    return;
  }
  while (head_ != nullptr) {
    delete head_->next_bll_;
    Node* the_next_node = head_->next_node_;
    delete head_;
    head_ = the_next_node;
  }
}

size_t BLL::SizeHelper(size_t current_size, BLL* go_through) const {
  Node* current = go_through->head_;
  while (current != nullptr) {
    current_size++;
    if (current->next_bll_ != nullptr) {
      current_size = SizeHelper(current_size, current->next_bll_);
    }
    current = current->next_node_;
  }
  return current_size;
}

Node* BLL::GetAtHelper(Node* answer,
                       size_t& iterate,
                       size_t idx,
                       BLL* go_through) const {
  Node* current = go_through->head_;
  while (iterate != idx && current != nullptr) {
    iterate++;
    if (current->next_bll_ != nullptr) {
      answer = GetAtHelper(answer, iterate, idx, current->next_bll_);
      if (iterate == idx && answer != nullptr) {
        return answer;
      }
    }
    current = current->next_node_;
  }
  return current;
}

// function implementations
BLL::BLL(const BLL& to_copy) {
  // edge case: empty copy
  if (to_copy.head_ == nullptr) {
    head_ = nullptr;
  } else {
    // normal stuff
    Node* to_copy_current = to_copy.head_;

    while (to_copy_current != nullptr) {
      Node* created = PushBack(to_copy_current->data_);
      if (to_copy_current->next_bll_ != nullptr) {
        created->next_bll_ = new BLL(*to_copy_current->next_bll_);
      }
      to_copy_current = to_copy_current->next_node_;
    }
  }
}

BLL::~BLL() { Clear(); }

BLL& BLL::operator=(const BLL& rhs) {
  if (this == &rhs) {
    return *this;
  }
  Clear();
  if (rhs.head_ == nullptr) {
    head_ = nullptr;
  } else {
    Node* to_copy_current = rhs.head_;
    while (to_copy_current != nullptr) {
      Node* created = PushBack(to_copy_current->data_);
      if (to_copy_current->next_bll_ != nullptr) {
        created->next_bll_ = new BLL(*to_copy_current->next_bll_);
      }
      to_copy_current = to_copy_current->next_node_;
    }
  }

  return *this;
}

Node* BLL::PushBack(char dat) {
  Node* to_add = new Node(dat);
  // edge case: adding in front of head
  if (head_ == nullptr) {
    head_ = to_add;
  } else {
    Node* current = head_;
    while (current->next_node_ != nullptr) {
      current = current->next_node_;
    }
    current->next_node_ = to_add;
  }
  return to_add;
}

char BLL::GetAt(size_t idx) const {
  size_t the_size = this->Size();
  if (idx >= the_size) {
    throw std::invalid_argument("nope");
  }
  Node* current = head_;
  Node* node_answer = nullptr;
  size_t iterator = 0;
  char answer = '\0';
  while (iterator != idx && current != nullptr) {
    iterator++;
    if (current->next_bll_ != nullptr) {
      // go through those nodes
      node_answer = GetAtHelper(node_answer, iterator, idx, current->next_bll_);
      if (iterator == idx && node_answer != nullptr) {
        answer = node_answer->data_;
        return answer;
      }
    }
    current = current->next_node_;
  }
  answer = current->data_;
  return answer;
}

void BLL::SetAt(size_t idx, char dat) {
  // call helper function(getting, make var for iterate, idx, this)
  size_t the_size = this->Size();
  if (idx >= the_size) {
    throw std::invalid_argument("nope");
  }
  Node* getting = nullptr;
  size_t iterate = 0;
  getting = GetAtHelper(getting, iterate, idx, this);
  getting->data_ = dat;
}

void BLL::Join(size_t idx, BLL* list) {
  // check to see if there's already an BLL at idx
  /*
  if (!this->IsBLLAcyclic()) {
    throw std::invalid_argument("nope");
  }
  */
  Node* current = head_;
  size_t index = 0;
  while (index < idx) {
    index++;
    current = current->next_node_;
  }
  if (current->next_bll_ != nullptr) {
    throw std::invalid_argument("nope");
  }
  current->next_bll_ = list;
}

std::string BLL::ToString() const {
  // only for a single branch right now
  std::string to_return;
  size_t size = this->Size();
  for (size_t i = 0; i < size; ++i) {
    to_return += this->GetAt(i);
  }
  return to_return;
}

size_t BLL::Size() const {
  // recursion?
  // incomplete right now, doesn't take into account any branches
  size_t to_return = 0;
  Node* current = head_;
  while (current != nullptr) {
    to_return++;
    if (current->next_bll_ != nullptr) {
      to_return = SizeHelper(to_return, current->next_bll_);
    }
    current = current->next_node_;
  }
  return to_return;
}

bool BLL::IsBLLAcyclic() const {
  if (head_ == nullptr) {
    return true;
  }
  Node* oogway = head_;
  Node* shifu = nullptr;
  bool shifu_check = false;
  if (oogway->next_bll_ != nullptr) {
    shifu = head_->next_bll_->head_;
  } else {
    shifu = head_->next_node_;
    shifu_check = true;
  }

  while (oogway != nullptr && shifu != nullptr &&
         shifu->next_node_ != nullptr) {
    // if oogway's next bll is not nullptr, recurse?
    if (oogway->next_bll_ != nullptr) {
      // call helper function on (oogway, shifu, oogway's next bll)
      AcyclicHelper(oogway, shifu, oogway->next_bll_);
    }
    if (oogway == shifu) {
      return false;
    }
    oogway = oogway->next_node_;
    shifu = shifu->next_node_->next_node_;
  }
  return true;
}

bool BLL::AcyclicHelper(Node* o, Node* s, BLL* go_through) const {
  o = go_through->head_;
  s = go_through->head_->next_node_;
  while (o != nullptr && s != nullptr && s->next_node_ != nullptr) {
    if (o->next_bll_ != nullptr) {
      AcyclicHelper(o, s, o->next_bll_);
    }
    if (o == s) {
      return false;
    }
    o = o->next_node_;
    s = s->next_node_->next_node_;
  }
  return true;
}