#include <iostream>

#include "dna_strand.hpp"

int main() {
  DNAstrand test;
  test.PushBack('c');
  test.PushBack('t');
  test.PushBack('g');
  test.PushBack('a');
  test.PushBack('a');
  test.PushBack('t');
  test.PushBack('t');
  test.PushBack('c');
  test.PushBack('g');
  char pattern[] = "gaattc";
  DNAstrand to_splice;
  to_splice.PushBack('t');
  to_splice.PushBack('g');
  to_splice.PushBack('a');
  to_splice.PushBack('t');
  to_splice.PushBack('c');
  test.SpliceIn(pattern, to_splice);
  Node* current = test.GetHead();
  while (current != nullptr) {
    std::cout << current->data << std::endl;
    current = current->next;
  }
  std::cout << "\n" << std::endl;
  std::cout << test.GetHead()->data << std::endl;
  std::cout << test.GetTail()->data << std::endl;
}