#include "dna_strand.hpp"

DNAstrand::~DNAstrand() {
  while (head_ != nullptr) {
    Node* next = head_->next;
    delete head_;
    head_ = next;
  }

  head_ = nullptr;
  tail_ = nullptr;
}

// for testing
void DNAstrand::PushBack(char value) {
  if (head_ == nullptr) {
    head_ = tail_ = new Node(value);
  } else {
    Node* temp = new Node(value);
    tail_->next = temp;
    tail_ = temp;
  }
}

Node* DNAstrand::GetHead() { return head_; }

Node* DNAstrand::GetTail() { return tail_; }

void DNAstrand::SpliceIn(const char* pattern, DNAstrand& to_splice_in) {
  if (to_splice_in.head_ == nullptr || *pattern == '\0') {
    return;
  }
  if (&to_splice_in == this) {
    return;
  }

  // iteration to find length of pattern
  size_t iterator = 0;
  size_t size_pattern = 0;
  while (pattern[iterator] != '\0') {
    iterator++;
    size_pattern++;
  }

  Node* current = head_;
  size_t counter = 0;
  size_t pos_beg = 0;
  size_t pos_end = 0;
  size_t loc = 0;

  int max_pos_beg = -1;
  int max_pos_end = -1;
  while (current != nullptr) {
    loc++;
    if (current->data == pattern[0]) {
      counter++;
      pos_beg = loc;
      current = current->next;
      while (current != nullptr && current->data == pattern[counter]) {
        loc++;
        counter++;
        current = current->next;
        if (counter >= size_pattern) {
          break;
        }
      }
      if (counter != size_pattern) {
        counter = 0;
        pos_beg = 0;
        pos_end = 0;
      } else {
        if ((int)pos_beg >= max_pos_beg) {
          max_pos_beg = (int)pos_beg;
          max_pos_end = (int)loc;
        }
        pos_end = loc;
        counter = 0;
        pos_beg = 0;
      }
    } else {
      counter = 0;
      pos_beg = 0;
      pos_end = 0;
      current = current->next;
    }
  }
  if (max_pos_end == -1) {
    throw std::invalid_argument("wrong");
  }

  // first make node to save the second half of the sequence
  current = head_;
  size_t count = 1;
  while ((int)count <= max_pos_end) {
    count++;
    current = current->next;
  }
  Node* saver = current;

  // iterate through sequence to delete nodes that match pattern
  current = head_;
  Node* next_node = nullptr;
  size_t iterate = 1;

  while ((int)iterate < max_pos_beg - 1) {
    iterate++;
    current = current->next;
  }
  Node* anotha_current = current->next;
  iterate++;
  current->next = nullptr;

  while ((int)iterate <= max_pos_end) {
    iterate++;
    next_node = anotha_current->next;
    delete anotha_current;
    anotha_current = next_node;
  }

  // now splice the to_splice_in into the sequence
  current = head_;
  size_t position = 1;
  while ((int)position < max_pos_beg - 1) {
    position++;
    current = current->next;
  }

  current->next = to_splice_in.head_;
  to_splice_in.tail_->next = saver;

  // edge case: if the cleaved part started from the beginning of the sequence
  if (max_pos_beg == 1) {
    head_ = to_splice_in.head_;
  }
  // edge case: if cleaved part goes until the end of the sequence
  if (saver == nullptr) {
    tail_ = to_splice_in.tail_;
  } else {
    Node* iterator = saver;
    while (iterator->next != nullptr) {
      iterator = iterator->next;
    }
    tail_ = iterator;
  }
  to_splice_in.head_ = nullptr;
  to_splice_in.tail_ = nullptr;
}
