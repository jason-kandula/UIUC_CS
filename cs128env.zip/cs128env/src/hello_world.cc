#include <iostream>

int main() {
  std::cout << "Hello, World!" << std::endl;

  std::vector<int> get_ints_from_file(std::string file_name) {
    std::ifstream ifs(file_name);
    int value = 0;
    while (ifs.good()) {
      ifs << value;
      if (ifs.bad()) {
        // terminate
      } else if (ifs.fails()) {
        ifs.clear();
        ifs.ignore(1, " ");
      } else {
        std::cout << value << std::endl;
      }
    }
  }
}