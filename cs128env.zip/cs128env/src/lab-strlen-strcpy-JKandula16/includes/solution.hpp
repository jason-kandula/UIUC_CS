#ifndef SOLUTION_HPP
#define SOLUTION_HPP

unsigned int StrLen(const char* c_str);

void StrCpy(char*& to, const char* from);

#endif