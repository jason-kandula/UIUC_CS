#include "solution.hpp"

unsigned int StrLen(const char* c_str) {
  unsigned int answer = 0;
  int i = 0;
  while (c_str[i] != '\0') {
    answer++;
    i++;
  }
  return answer;
}

void StrCpy(char*& to, const char* from) {
  if (from == nullptr) {
    return;
  }
  unsigned int size = StrLen(from) + 1;
  char* c_str_new = new char[size];
  for (unsigned int i = 0; i < (StrLen(from) + 1); ++i) {
    c_str_new[i] = from[i];
  }
  c_str_new[StrLen(from)] = '\0';

  // deallocation of "to"
  delete[] to;
  to = nullptr;
  to = c_str_new;
}