#include <iostream>

#include "solution.hpp"

int main() {
  char c_string[100] = "c-style string";
  char c_string2[] = "c-style string";
  char c_string3[] = "";
  std::cout << sizeof(c_string) << std::endl;
  std::cout << StrLen(c_string) << std::endl;
  std::cout << "\n" << std::endl;

  std::cout << sizeof(c_string2) << std::endl;
  std::cout << StrLen(c_string2) << std::endl;
  std::cout << "\n" << std::endl;

  std::cout << sizeof(c_string3) << std::endl;
  std::cout << StrLen(c_string3) << std::endl;
  std::cout << "\n" << std::endl;
}