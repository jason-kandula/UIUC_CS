#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <cctype>
#include <string>
#include <vector>

// Your function declarations should go in this header file.
bool Monke(std::string arg);
std::string Convert(std::string arg);
char BigW(std::string arg);
std::string Vowels(char arg);
bool CheckVowel(char arg);
std::string WackVowels(std::string arg);
bool CheckWackVowels(std::string arg);

#endif