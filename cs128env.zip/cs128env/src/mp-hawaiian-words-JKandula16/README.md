# CS-128 : MP : Hawaiian Words
See the prompt on cs128.org.