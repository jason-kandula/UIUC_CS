#include "functions.hpp"

#include <iostream>
#include <string>
#include <vector>
// Your function definitions should go in this source file.

bool Monke(std::string arg) {
  std::vector<char> valid = {
      'a', 'e', 'i', 'o', 'u', 'p', 'k', 'h', 'l', 'm', 'n', 'w', ' ', '\''};
  std::string check;
  std::string new_arg;
  for (size_t i = 0; i < arg.size(); ++i) {
    new_arg.push_back(tolower(arg.at(i)));
  }
  for (size_t i = 0; i < new_arg.size(); ++i) {
    for (size_t j = 0; j < valid.size(); ++j) {
      if (new_arg.at(i) != valid.at(j)) {
        continue;
      }
      if (new_arg.at(i) == valid.at(j)) {
        check.push_back(new_arg.at(i));
        break;
      }
    }
  }
  return check.size() == new_arg.size();
}

std::string Convert(std::string arg) {
  std::string new_arg;
  for (size_t i = 0; i < arg.size(); ++i) {
    new_arg.push_back(tolower(arg.at(i)));
  }
  if (!(Monke(new_arg))) {
    return arg + " contains a character not a part of the Hawaiian language.";
  }
  std::string check;
  for (size_t i = 0; i < new_arg.size(); ++i) {
    if (new_arg.at(i) == 'p' || new_arg.at(i) == 'k' || new_arg.at(i) == 'h' ||
        new_arg.at(i) == 'l' || new_arg.at(i) == 'm' || new_arg.at(i) == 'n') {
      check.push_back(new_arg.at(i));
    } else if (new_arg.at(i) == 'w') {
      check += BigW(new_arg);
    } else if (CheckVowel(new_arg.at(i))) {
      if (i == new_arg.size() - 1) {
        if (CheckVowel(new_arg.at(i))) {
          check += Vowels(new_arg.at(i));
          check += "-";
        }
      } else if (CheckVowel(new_arg.at(i + 1))) {
        std::string to_check = new_arg.substr(i, 2);
        if (CheckWackVowels(to_check)) {
          check += WackVowels(to_check);
          check += "-";
          i++;
        } else {
          check += Vowels(new_arg.at(i));
          check += "-";
        }
      } else {
        check += Vowels(new_arg.at(i));
        check += "-";
      }
    } else if (new_arg.at(i) == '\'') {
      check = check.substr(0, check.size() - 1);
      check.push_back(new_arg.at(i));
    }

    if (i == new_arg.size() - 1) {
      check = check.substr(0, check.size() - 1);
    }
    if (new_arg.at(i) == ' ') {
      check = check.substr(0, check.size() - 1);
      check.push_back(new_arg.at(i));
    }
  }
  return check;
}

char BigW(std::string arg) {
  for (size_t i = 0; i < arg.size(); ++i) {
    if (arg.at(0) == 'w') {
      return 'w';
    }
    if (arg.at(i) == 'w' && (arg.at(i - 1) == 'i' || arg.at(i - 1) == 'e')) {
      return 'v';
    }
  }
  return 'w';
}

std::string Vowels(char arg) {
  std::string s;
  if (arg == 'a') {
    s = "ah";
  } else if (arg == 'e') {
    s = "eh";
  } else if (arg == 'i') {
    s = "ee";
  } else if (arg == 'o') {
    s = "oh";
  } else if (arg == 'u') {
    s = "oo";
  }
  return s;
}

bool CheckVowel(char arg) {
  std::vector<char> vowels = {'a', 'e', 'i', 'o', 'u'};
  for (size_t i = 0; i < vowels.size(); ++i) {
    if (arg == vowels.at(i)) {
      return true;
    }
  }
  return false;
}

bool CheckWackVowels(std::string arg) {
  bool check = false;
  if (arg == "ai" || arg == "ae") {
    check = true;
  }
  if (arg == "ao" || arg == "au") {
    check = true;
  }
  if (arg == "ei") {
    check = true;
  }
  if (arg == "eu") {
    check = true;
  }
  if (arg == "iu") {
    check = true;
  }
  if (arg == "oi") {
    check = true;
  }
  if (arg == "ou") {
    check = true;
  }
  if (arg == "ui") {
    check = true;
  }
  return check;
}

std::string WackVowels(std::string arg) {
  std::string s;
  if (arg == "ai" || arg == "ae") {
    s = "eye";
  }
  if (arg == "ao" || arg == "au") {
    s = "ow";
  }
  if (arg == "ei") {
    s = "ay";
  }
  if (arg == "eu") {
    s = "eh-oo";
  }
  if (arg == "iu") {
    s = "ew";
  }
  if (arg == "oi") {
    s = "oy";
  }
  if (arg == "ou") {
    s = "ow";
  }
  if (arg == "ui") {
    s = "ooey";
  }
  return s;
}