# Visual debugging

See the prompt on cs128.org.
