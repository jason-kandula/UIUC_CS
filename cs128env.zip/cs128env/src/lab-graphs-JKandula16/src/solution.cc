#include "solution.hpp"

#include <iostream>
#include <queue>

Solution::Solution(
    const std::vector<std::pair<std::string, std::string>>& prerequisites) {
  for (size_t i = 0; i < prerequisites.size(); ++i) {
    if (adj_.count(prerequisites[i].first) == 0) {
      AddVertex(prerequisites[i].first);
    }
  }
  for (const std::pair<std::string, std::string>& p : prerequisites) {
    adj_.at(p.first).push_back(p.second);
  }
}

int Solution::Solve(const std::string& start, const std::string& dest) {
  int answer = 0;
  std::map<std::string, int> depth_tracker;
  std::queue<std::string> visited;
  std::set<std::string> visited_set;
  visited.push(start);
  visited_set.insert(start);
  depth_tracker.insert({start, 0});
  while (!visited.empty()) {
    std::string temp = visited.front();
    visited.pop();
    for (std::string s : adj_[temp]) {
      if (s == dest) {
        return depth_tracker[temp] + 1;
      }
      if (visited_set.count(s) == 0) {
        visited.push(s);
        visited_set.insert(s);
        depth_tracker.insert({s, depth_tracker[temp] + 1});
      }
    }
  }

  if (depth_tracker.count(dest) > 0) {
    answer = depth_tracker.at(dest);
    return answer;
  }

  return -1;
}

///////////////////////////////////////////////////////////////////////////////
// Provide function definitions (uncomment to use!) //
///////////////////////////////////////////////////////////////////////////////

void Solution::AddVertex(const std::string& vertex) {
  if (VertexInGraph(vertex))
    throw std::runtime_error("vertex already in graph.");
  adj_.insert(std::pair<std::string, std::list<std::string>>(
      vertex, std::list<std::string>()));
}

std::list<std::string>& Solution::GetAdjacencyList(const std::string& vertex) {
  return adj_.find(vertex)->second;
}

bool Solution::VertexInGraph(const std::string vertex_) {
  if (adj_.find(vertex_) != adj_.end())
    return true;
  else
    return false;
}

std::ostream& operator<<(std::ostream& os, const Solution& sol) {
  os << "Contents:" << std::endl;

  for (const auto& pair : sol.adj_) {
    os << "  " << pair.first << ": [ ";

    for (const auto& list_entry : pair.second) {
      os << list_entry << " ";
    }

    os << "]" << std::endl;
  }

  return os;
}