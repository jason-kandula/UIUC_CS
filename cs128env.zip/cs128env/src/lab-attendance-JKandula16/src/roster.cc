#include "roster.hpp"

#include <iostream>

Roster::Roster(const Student& student) {
  // TODO
  head_ = std::make_unique<RosterEntry>(student, nullptr);
}

void Roster::AddStudent(const Student& student) {
  // TODO
  if (head_ == nullptr || head_->student > student) {
    if (head_ == nullptr) {
      head_ = std::make_unique<RosterEntry>(student, nullptr);
    } else {
      std::unique_ptr<RosterEntry> new_head =
          std::make_unique<RosterEntry>(student, nullptr);
      new_head->next = std::move(head_);
      head_ = std::move(new_head);
    }
  } else {
    RosterEntry* current = head_.get();
    std::unique_ptr<RosterEntry> insert =
        std::make_unique<RosterEntry>(student, nullptr);

    while (current->next != nullptr && current->next->student < student) {
      current = current->next.get();
    }
    if (current->next != nullptr) {
      // insert the student in front of current->next
      insert->next = std::move(current->next);
      current->next = std::move(insert);
    } else {
      current->next = std::move(insert);
    }
  }

  return;
}

Roster::Iterator Roster::begin() const { return Iterator(head_.get()); }

Roster::Iterator Roster::end() const { return Iterator(); }
