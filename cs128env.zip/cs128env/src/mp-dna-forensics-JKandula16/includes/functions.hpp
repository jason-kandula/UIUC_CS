#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <fstream>
#include <iostream>
#include <map>

#include "utilities.hpp"

int LongestConsecStr(std::string dna, std::string str);

std::string Match(std::map<std::vector<int>, std::string> the_map,
                  std::vector<int> longest);

#endif