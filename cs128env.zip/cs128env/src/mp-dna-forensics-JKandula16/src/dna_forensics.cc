#include <fstream>
#include <iostream>

#include "functions.hpp"
#include "utilities.hpp"

int main(int argc, char* argv[]) {
  if (argc != 3) {
    std::cerr << "Usage: " << argv[0] << " [input_file] [dna_sequence]"
              << std::endl;
    return 1;
  }
  // gets the csv file from the user
  std::string csv = argv[1];
  std::ifstream ifs{csv};
  std::map<std::vector<int>, std::string> map_dna_values;
  std::vector<std::string> str_values;
  for (std::string line; std::getline(ifs, line); line = "") {
    std::vector<std::string> vec = utilities::GetSubstrs(line, ',');
    std::vector<int> temp;
    if (str_values.empty()) {
      for (size_t i = 1; i < vec.size(); ++i) {
        str_values.push_back(vec.at(i));
      }
    } else {
      for (size_t i = 1; i < vec.size(); ++i) {
        int val = std::stoi(vec.at(i));
        temp.push_back(val);
      }
      map_dna_values[temp] = vec.at(0);
    }
  }
  std::vector<int> longest_consec_vals;
  for (size_t i = 0; i < str_values.size(); ++i) {
    int longest = LongestConsecStr(argv[2], str_values.at(i));
    longest_consec_vals.push_back(longest);
  }

  std::string final_ans = Match(map_dna_values, longest_consec_vals);
  std::cout << final_ans << std::endl;
}