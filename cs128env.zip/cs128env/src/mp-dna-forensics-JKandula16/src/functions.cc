#include "functions.hpp"

#include "utilities.hpp"

int LongestConsecStr(std::string dna, std::string str) {
  int count = 0;
  int max_count = 0;
  for (size_t i = 0; i < dna.size(); i++) {
    if (dna.substr(i, str.size()) == str) {
      count++;
      i = i + str.size() - 1;
    } else {
      if (count >= max_count) {
        max_count = count;
      }
      count = 0;
    }
  }
  if (count >= max_count) {
    max_count = count;
  }
  return max_count;
}

std::string Match(std::map<std::vector<int>, std::string> the_map,
                  std::vector<int> longest) {
  for (auto map_pair : the_map) {
    int check = 0;
    std::vector<int> temp = map_pair.first;
    for (size_t i = 0; i < temp.size(); ++i) {
      if (temp.at(i) != longest.at(i)) {
        check++;
      }
    }
    if (check == 0) {
      return map_pair.second;
    }
  }
  return "No match";

  /*
  if (the_map.contains(longest)) {
    return the_map[longest];
  }
  return "No match";
  */
}